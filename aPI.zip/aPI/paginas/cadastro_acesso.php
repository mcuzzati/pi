<?PHP	
  session_start();
	if (!empty($_REQUEST['param_carta'])) 					{ $param_carta = trim($_REQUEST['param_carta']); } else { $param_carta = "NAO INFORMADO"; };
  
	require_once("seg_conexao.php");
		
  try 
  {
    $pdo = connect();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  } catch(PDOException $e) {
    $e->getMessage();
    echo "<span class='fonte_doze_negrito_erro'>[ Erro $e ]</span>";
    exit;
  };
    
  $vErroCodigo = "";
    
  $param_nome_registro = "";
  $param_nome_social = "";
  $param_data_nasc = "";
  $param_cpf = "";
  $param_ddd01 = "";
  $param_telefone01 = "";
  $param_tipo01 = "";
  $param_ddd02 = "";
  $param_telefone02 = "";
  $param_tipo02 = "";
  $param_cep = "";
  $param_uf = "";
  $param_cidade = "";
  $param_logradouro = "";
  $param_numero = "";
  $param_bairro = "";
  $param_complemento = "";
  $param_caixa_postal = "";
  $param_email = "";
  $param_tipo_email = "";
  $param_senha = "";
  $param_conf_senha = "";
  
  $vCamposObrigatorios = "";
  
	if(isset($_REQUEST['bt_gravar']))
  {   
    if (!empty($_REQUEST['cp_nome_registro'])) 	{ $param_nome_registro = trim($_REQUEST['cp_nome_registro']); };
    if (!empty($_REQUEST['cp_nome_social'])) 		{ $param_nome_social = trim($_REQUEST['cp_nome_social']); };
    if (!empty($_REQUEST['cp_email'])) 					{ $param_email = trim($_REQUEST['cp_email']); };
    if (!empty($_REQUEST['cp_senha'])) 		      { $param_senha = trim($_REQUEST['cp_senha']); };
    if (!empty($_REQUEST['cp_conf_senha'])) 		{ $param_conf_senha = trim($_REQUEST['cp_conf_senha']); };
       
    $vSeparador = "";
    if (empty($param_nome_registro)) { $vCamposObrigatorios = "Nome de Registro"; $vSeparador = ", "; };
    if (empty($param_nome_social))   { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Nome de Registro"; $vSeparador = ", "; };
    if (empty($param_email))         { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."E-mail"; $vSeparador = ", "; };
    if (empty($param_senha))         { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Senha"; $vSeparador = ", "; };
    if (empty($param_conf_senha))    { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Confirmação de Senha"; $vSeparador = ", "; };
    
    if (!empty($vCamposObrigatorios))
    {
      $vCamposObrigatorios = $vCamposObrigatorios ." são campos obrigatório(s)."; 
      
      if (!empty($param_senha) and !empty($param_conf_senha))
      {
        if ($param_senha <> $param_conf_senha)
        {
          $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."<br>Senha e Confirmação de Senha não podem ser diferente.";
        }
      }
      $vCamposObrigatorios = "<font color='red' font-size: 14px>". $vCamposObrigatorios ."</font>"; 
    }
    else
    {
      if (!empty($param_senha) and !empty($param_conf_senha))
      {
        if ($param_senha <> $param_conf_senha)
        {
          $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."<font color='red' font-size: 14px>Senha e Confirmação de Senha não podem ser diferente.</font>";
        }
      }
    }
    
    if (empty($vCamposObrigatorios))
    {
      if (!empty($param_data_nasc))
      {
      	$vet_data = explode("/",$param_data_nasc);
      	$param_data_nasc_formatada = $vet_data[2]."-".$vet_data[1]."-".$vet_data[0];
      }
      if (!empty($param_cpf))
      {
      	$param_cpf_numeros = preg_replace("/[^0-9]/", "", $param_cpf);
      }
      if (!empty($param_cpf))
      {
      	$param_cep_numeros = preg_replace("/[^0-9]/", "", $param_cep);
      }
     
      try 
      { // CADASTRO DE PESSOA
        $sql = "insert into pessoa
                (alteracao, id_usuario_alteracao, nome_oficial, nome_social, email)
                values (now(), :ID_USER_EXECUCAO, :NOME_OFICIAL, :NOME_SOCIAL, :EMAIL_01)";
        $parametros_sql = array(":ID_USER_EXECUCAO"=>3,
                                ":NOME_OFICIAL"=>$param_nome_registro, 
                                ":NOME_SOCIAL"=>$param_nome_social, 
                                ":EMAIL_01"=>$param_email);
        $stmt= $pdo->prepare($sql);
        $stmt->execute($parametros_sql);
        $vCodPessoa = $pdo->lastInsertId('cod_pessoa');
        
        if (!empty($vCodPessoa) and $vCodPessoa > 0)
        { // CADASTRO DE USUARIO DA PESSOA
          $sql = "insert into usuario
                  (alteracao, id_usuario_alteracao, usuario, senha, tipo_usuario, cod_pessoa)
                  values (now(), :ID_USER_EXECUCAO, :USUARIO, :SENHA, :TIPO_USUARIO, :COD_PESSOA)";
          $parametros_sql = array(":ID_USER_EXECUCAO"=>3,
                                  ":USUARIO"=>$param_email, 
                                  ":SENHA"=>$param_senha, 
                                  ":TIPO_USUARIO"=>"CN",
                                  ":COD_PESSOA"=>$vCodPessoa);
          $stmt= $pdo->prepare($sql);
          $stmt->execute($parametros_sql);
          $vCodUsuario = $pdo->lastInsertId('cod_usuario');
          
          if (!empty($vCodUsuario) and $vCodUsuario > 0)
          {
            echo("<font color='blue font-size: 16px'>Usuário cadastrado com sucesso.</font>");
            echo("<script language='Javascript'>window.location = 'index.php'</script>");
          }
          else
          {
            $vCamposObrigatorios = "<font color='red font-size: 14px'>Cadastro não foi concluído. Tente novamente.</font>";
          }
        }
        else
        {
          $vCamposObrigatorios = "<font color='red font-size: 14px'>Cadastro não foi concluído. Tente novamente.</font>";
        }
      } 
      catch (PDOException $e) 
      {
        $e->getMessage();
        $vErroCodigo = $vErroCodigo ."Cadastro de usuário. Erro: $e <br>";
      };
    };
	};
?>

<!DOCTYPE>
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Cadastro</title>
    <script type="text/javascript" src="./js/jquery.js"></script>
    <script type="text/javascript" src="./js/jquery.maskedinput.js"/></script>
    <script>
    function Carrega_Formulario()
    {
      $("#div_cabecalho").load("cabecalho_ajax.php", {param_funcao: 'carregar'});
    }
    
    function ValidarUsuario()
    {
      $("#div_cabecalho").load("cabecalho_ajax.php", {param_funcao: 'validar_acesso', param_email: $("#var_email").val(), param_senha: $("#var_senha").val()});
    }
    
    function Logof()
    {
      $("#div_cabecalho").load("cabecalho_ajax.php", {param_funcao: 'logof'});
    }
    
    $(document).ready(function(){
      $("#cp_cpf").mask("999.999.999-99");
      $("#cp_cep").mask("99.999-999");
    });
    
    function mascaraData( campo, e )
    {
      var kC = (document.all) ? event.keyCode : e.keyCode;
      var data = campo.value;
      
      if( kC!=8 && kC!=46 )
      {
        if( data.length==2 )
        {
          campo.value = data += '/';
        }
        else if( data.length==5 )
        {
          campo.value = data += '/';
        }
        else
          campo.value = data;
      }
    }
    
    function validacaoEmail(field) 
    {
      usuario = field.value.substring(0, field.value.indexOf("@"));
      dominio = field.value.substring(field.value.indexOf("@")+ 1, field.value.length);

      if ((usuario.length >=1) &&
          (dominio.length >=3) &&
          (usuario.search("@")==-1) &&
          (dominio.search("@")==-1) &&
          (usuario.search(" ")==-1) &&
          (dominio.search(" ")==-1) &&
          (dominio.search(".")!=-1) &&
          (dominio.indexOf(".") >=1)&&
          (dominio.lastIndexOf(".") < dominio.length - 1)) {
        document.getElementById("span_msg").innerHTML="";
      }
      else
      {
        document.getElementById("span_msg").innerHTML="<font style='color: #FF0000;'>E-mail inválido</font>";
      }
    }
    
    function comparar_senha()
    {
      var vSenha = document.getElementById("cp_senha").value;
      var vConferirSenha = document.getElementById("cp_conf_senha").value;
      if (vSenha != vConferirSenha) 
      {
        document.getElementById("span_msg").innerHTML = "<font style='color: #FF0000;'>Senha e Confirmação de senha estão diferentes.</font>";
      }
      else
      {
        document.getElementById("span_msg").innerHTML = "";
      }
    }
    
    function BuscaCPF()
    {
      if (document.getElementById("cp_cpf").value != "") 
      {
        $.getJSON("cadastro_ajax.php", {param_funcao: "busca_cpf", param_cpf: document.getElementById("cp_cpf").value}, function(data){
          if (data[0] != 0)
          {
            document.getElementById("span_msg").innerHTML = "<font color='red'>CPF " + document.getElementById("cp_cpf").value + " já consta no cadastro.</font>";
          };
        });
      };
    }
    
    function BuscaEmail()
    {
      if (document.getElementById("cp_email").value != "") 
      {
        $.getJSON("cadastro_ajax.php", {param_funcao: "busca_email", param_email: document.getElementById("cp_email").value}, function(data){
          if (data[0] != 0)
          {
            document.getElementById("span_msg").innerHTML = "<font color='red'>E-mail " + document.getElementById("cp_email").value + " já consta no cadastro.</font>";
          };
        });
      };
    }
    
    function copia_nome()
    {
      if ($("#cp_nome_social").val() == "")
      {
        document.getElementById("cp_nome_social").value = $("#cp_nome_registro").val();
      }
    }
    
    function proximo_campo(vCampo)
    {
      if (vCampo == "cp_numero")
      {
        if ($("#cp_bairro").val() != "")
        {
          document.getElementById("cp_email").focus();
        }
      }
    }
    </script>
    <style type="text/css">
	  @import "css.css";
    </style>
  </head>
  <body onLoad="Carrega_Formulario()">
    <div id="div_cabecalho"></div>
    <table width="100%" border="0" align="center" background="./img/fundo_principal.png">
      <tr>
        <td height="135px">
          <table width="1000px" border="0" align="center">
            <tr>
              <td class="titulo_azul_20" height="50px" colspan="2"><br><br>Cadastro de Acesso<br><br></td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
    <center><br>
    <form id="FA" name="FA" method="post" action="cadastro_acesso.php">
      <table width="800px" border="0" cellspacing="2" cellpadding="2">
				<tr>
          <td class="fonte12_esq"><b>Nome de Registro <span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="8"><input type="text" name="cp_nome_registro" id="cp_nome_registro" placeholder="Nome de Registro" value="<?php echo($param_nome_registro); ?>" size="90" onBlur="copia_nome();"></td>
        </tr>
				<tr>
          <td class="fonte12_esq"><b>Nome Social <span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="8"><input type="text" name="cp_nome_social" id="cp_nome_social" placeholder="Nome Social" value="<?php echo($param_nome_social); ?>" size="90"></td>
        </tr>
				<tr>
          <td class="fonte12_esq"><b>E-mail <span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="3"><input type="text" name="cp_email" id="cp_email" placeholder="E-mail" value="<?php echo($param_email); ?>" size="40" onBlur="BuscaEmail()"></td>
          <td class="fonte12_esq"><b>Conf. de E-mail <span style="color:red">*</span></b></td>
          <td class="fonte12_esq"><input type="text" name="cp_conf_email" id="cp_conf_email" placeholder="Confirmação de E-mail" value="<?php echo($param_email); ?>" size="30" onBlur="ConfEmail()"></td>
        </tr>
				<tr>
          <td class="fonte12_esq"><b>Senha <span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="2"><input type="password" name="cp_senha" id="cp_senha" value="<?php echo($param_senha); ?>" size="15" minlength="6" onchange="comparar_senha()"></td>
          <td class="fonte12_esq"><b>Confirmação de Senha <span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="2"><input type="password" name="cp_conf_senha" id="cp_conf_senha" value="<?php echo($param_conf_senha); ?>" size="15" minlength="6" onchange="comparar_senha()"><span id="span_msg_senha"></span></td>
        </tr>
				<tr>
          <td class="fonte14" colspan="6"><span id="span_msg"><?php echo($vCamposObrigatorios); ?></span></td>
        </tr>
				<tr>
          <td class="fonte14" colspan="6"><input type="submit" class="button_padrao" name="bt_gravar" value="&nbsp;&nbsp;Gravar&nbsp;&nbsp;"></td>
        </tr>
      </table>
    </form>
    <?php echo($vErroCodigo); ?>
  </body>
</html>