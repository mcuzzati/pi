<?php	
  session_start();
  if (!isset($_SESSION['param_usuario']) or $_SESSION['param_tipo_usuario'] <> "CL")
  { 
    session_destroy();
    echo("<script language='Javascript'>window.location = 'index.php'</script>");
  }

  require_once("seg_conexao.php");
  
  try 
	{  
	  $pdo = connect();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	}
	catch(PDOException $e)
	{
		$e->getMessage();
		echo "<span class='fonte_doze_negrito_erro'>Conectando com Banco de Dados. [ Erro $e ]</span>";
		exit;
	};
  
  try 
	{ // Relaciona candidatos as vagas
    $sql = "insert into vaga_emprego_x_elegivel
            (alteracao, id_usuario_alteracao, cod_vaga_emprego, cod_pessoa_candidato)
            select distinct now(), 2, v.cod_vaga_emprego, p.cod_pessoa 
              from vaga_emprego v
                    inner join pessoa p
                     on (p.cod_grau_escolaridade = v.cod_grau_escolaridade
                         or p.cod_grau_escolaridade = v.cod_grau_escolaridade_minimo
                         or coalesce(p.salario_desejado,0) BETWEEN (v.salario - 200) and (v.salario + 200))
                    inner join pessoa_x_ocupacao o 
                      on (o.cod_ocupacao = v.cod_ocupacao
                          and o.cod_pessoa = p.cod_pessoa)
                    inner join usuario u on (u.tipo_usuario = 'CN' and u.cod_pessoa = p.cod_pessoa)
                    left join vaga_emprego_x_elegivel ve 
                     on (ve.cod_vaga_emprego = v.cod_vaga_emprego
                         and ve.cod_pessoa_candidato = p.cod_pessoa)
             where ve.cod_vaga_candidato is null
               and v.status = 'A'
             order by v.cod_vaga_emprego, p.cod_pessoa";
    $stmt= $pdo->prepare($sql);
    $stmt->execute();
	}
	catch(PDOException $e)
	{
		$e->getMessage();
		echo "<span class='fonte_doze_negrito_erro'>Conectando com Banco de Dados. [ Erro $e ]</span>";
		exit;
	};
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Lista de Vagas de Emprego</title>
<style type="text/css">
  @import "css.css";
  @import "./font-awesome/css/all.min.css"
</style>
<script type="text/javascript" src="./js/jquery.maskedinput.js" ></script>
<script type="text/javascript" src="./js/jquery.js"></script>
<script type="text/javascript" src="./js/jquery.form.js"></script>
<script type="text/javascript" src="./js/jquery.selects.js"></script>
<script language="javascript">
  function Carrega_Formulario()
  {
    $("#div_cabecalho").load("cabecalho_ajax.php", {param_funcao: 'carregar'});
  }
  
  function NovaVaga()
  {
    window.location = 'cadastro_vaga_emprego.php';
  }
  
  function Voltar()
  {
    window.location = 'menu_colaborador.php';
  }
</script>
</head>
<body onLoad="Carrega_Formulario()">
  <center>
  <div id="div_cabecalho"></div> 
  <table width="100%" border="0" align="center" background="./img/fundo_principal.png">
    <tr>
      <td height="135px">
        <table width="1000px" border="0" align="center">
          <tr>
            <td class="titulo_azul_20" height="50px" colspan="2"><br><br><br><br></td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
  <br>
  <table width="1000px" border="0" cellspacing="2" cellpadding="2">
    <tr height="40px">
      <td bgcolor="#a6bce8" class="titulo_padrao arredondamento_superior" colspan="5">
        <table width="100%" border="0" align="center">
          <tr>
            <td height="40px" class="titulo_padrao_interno">Vaga de Emprego</td>
            <td height="40px" width="110px">
              <button class="button_padrao" onclick="NovaVaga()">&nbsp;&nbsp;Nova Vaga&nbsp;&nbsp;</button>
            </td>
          </tr>
        </table>
      </td>
    </tr>
<?php  
  try 
  { 
		$sql = "select v.cod_vaga_emprego,
                   v.empresa,
                   o.ocupacao,
                   v.descritivo_vaga,
                   if(v.status='A','Aberta','Fechada') as status,
                   (select count(1)
                     from vaga_emprego_x_elegivel c
                    where c.aprovado = 'P'
                      and c.entrevistar is null
                      and c.cod_vaga_emprego = v.cod_vaga_emprego) as qtde_agendar_entrevistar,
                   (select count(1)
                     from vaga_emprego_x_elegivel c
                    where c.aprovado = 'P'
                      and c.entrevistar is not null
                      and c.cod_vaga_emprego = v.cod_vaga_emprego) as qtde_pend_entrevistar,
                   (select count(1)
                     from vaga_emprego_x_elegivel c
                    where c.aprovado = 'N'
                      and c.entrevistar is not null
                      and c.cod_vaga_emprego = v.cod_vaga_emprego) as qtde_reprovado,
                   (select count(1)
                     from vaga_emprego_x_elegivel c
                    where c.aprovado = 'S'
                      and c.entrevistar is not null
                      and c.cod_vaga_emprego = v.cod_vaga_emprego) as qtde_aprovado,
                   pa.nome_social as usuario_alteracao,
                   DATE_FORMAT(v.alteracao,'%d/%m/%Y %H:%i') as alteracao
              from vaga_emprego v
                    inner join usuario ua on (ua.cod_usuario = v.id_usuario_alteracao)
                    inner join pessoa pa on (pa.cod_pessoa = ua.cod_pessoa)
                    left join classificacao_ocupacao o on (o.cod_ocupacao = v.cod_ocupacao)";
    $stmt= $pdo->prepare($sql);
    $stmt->execute();
  }
  catch(PDOException $e)
  {
    $e->getMessage();
    echo "<span class='fonte_doze_negrito_erro'>[ Erro $e ]</span>";
    exit;
  };
  
  $vContador = 0; $vCorLinha == "#bfc8db";
  while ($result = $stmt->fetch(PDO::FETCH_ASSOC)) 
  {
    $vContador = ($vContador + 1);
    if ($vCorLinha == "#bfc8db") { $vCorLinha = "#ffffff"; } else { $vCorLinha = "#bfc8db"; };
?>
    <tr height="40px">
      <td bgcolor="<?php echo($vCorLinha); ?>" class="fonte14" width="40px">
        <a href="cadastro_vaga_emprego.php?op=ED&param_cod_vaga=<?php echo($result["cod_vaga_emprego"]); ?>">
          <span style="color: #9c5709; font-size: 25px;"><i class="icon_fa fas fa-edit" title="Editar Registro"></i></span></a>
      </td>
      <td bgcolor="<?php echo($vCorLinha); ?>" class="fonte14" width="40px">
        <a href="cadastro_vaga_emprego.php?op=EX&param_cod_vaga=<?php echo($result["cod_vaga_emprego"]); ?>">
          <span style="color: #9c0e09; font-size: 25px;"><i class="icon_fa fas fa-trash" title="Excluir Registro"></i></span></a>
      </td>
      <td bgcolor="<?php echo($vCorLinha); ?>" class="fonte12_esq" width="200px">
        <a href="lista_candidato_por_vaga.php?param_cod_vaga=<?php echo($result["cod_vaga_emprego"]); ?>">
        Pendente Agendar Entrevista: <?php echo($result["qtde_agendar_entrevistar"]); ?><br>
        Pendente Entrevistar: <?php echo($result["qtde_pend_entrevistar"]); ?><br>
        Reprovado(s): <?php echo($result["qtde_reprovado"]); ?><br>
        Aprovado(s): <?php echo($result["qtde_aprovado"]); ?></a>
      </td>
      <td bgcolor="<?php echo($vCorLinha); ?>" class="fonte14_esq">&nbsp;&nbsp;&nbsp;<b>Empresa: </b><?php echo($result["empresa"] ."<br>&nbsp;&nbsp;&nbsp;<b>Ocupação: </b>". $result["ocupacao"] ."<br>&nbsp;&nbsp;&nbsp;<b>Vaga: </b>". $result["descritivo_vaga"]); ?></td>
      <td bgcolor="<?php echo($vCorLinha); ?>" class="fonte12_esq" width="220px">&nbsp;&nbsp;&nbsp;Alterado em: <?php echo($result["alteracao"] ."<br>&nbsp;&nbsp;&nbsp;Por: ". $result["usuario_alteracao"]); ?></td>
    </tr>
<?php
  };
  
  if ($vContador == 0)
  {
?>
    <tr height="40px">
      <td bgcolor="<?php echo($vCorLinha); ?>" class="fonte14" colspan="5">Não há vagas</td>
    </tr>
<?php
  }
?>
    <tr height="15px">
      <td bgcolor="#a6bce8" class="titulo_padrao arredondamento_inferior" colspan="5">
        <button class="button_padrao" onclick="Voltar()">&nbsp;&nbsp;Voltar&nbsp;&nbsp;</button>
      </td>
    </tr>
  </table>
</body>
</html>
