<?PHP	
  session_start();
  if (!isset($_SESSION['param_usuario']) or $_SESSION['param_tipo_usuario'] <> "CL")
  { 
    session_destroy();
    echo("<script language='Javascript'>window.location = 'index.php'</script>");
  }
  
	if (!empty($_REQUEST['param_cod_pessoa_col'])) { $param_cod_pessoa_col = trim($_REQUEST['param_cod_pessoa_col']); } else { $param_cod_pessoa_col = "0"; };
  if (!empty($_REQUEST['op'])) { $op = trim($_REQUEST['op']); } else { $op = "X"; };
  
	require_once("seg_conexao.php");
  require_once("funcoes.php");
		
  try 
  {
    $pdo = connect();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  } catch(PDOException $e) {
    $e->getMessage();
    echo "<span class='fonte_doze_negrito_erro'>[ Erro $e ]</span>";
    exit;
  };
    
  $vErroCodigo = "";
    
  $param_nome_registro = "";
  $param_nome_social = "";
  $param_data_nasc = "";
  $param_cpf = "";
  $param_ddd01 = "";
  $param_telefone01 = "";
  $param_tipo01 = "";
  $param_ddd02 = "";
  $param_telefone02 = "";
  $param_tipo02 = "";
  $param_cep = "";
  $param_uf = "";
  $param_cidade = "";
  $param_logradouro = "";
  $param_numero = "";
  $param_bairro = "";
  $param_complemento = "";
  $param_caixa_postal = "";
  
  $param_email = "";
  $param_tipo_email = "";
  $param_senha = "";
  $param_conf_senha = "";
  $LblUsuario = "";
  
  $vCamposObrigatorios = "";
  
	if($op == "EX")
  { 
    try
    {
      $sql = "delete from usuario
               where cod_pessoa = :COD_PESSOA";
      $parametros_sql = array(":COD_PESSOA"=>$param_cod_pessoa_col);
      $stmt= $pdo->prepare($sql);
      $stmt->execute($parametros_sql);
      if( $stmt->rowCount() == 0 )
      {
        $vCamposObrigatorios = "<font color='red font-size: 14px'>Exclusão de usuário não foi concluída. Tente novamente.</font>";
      }
      else
      {
        $sql = "delete from pessoa
                 where cod_pessoa = :COD_PESSOA";
        $parametros_sql = array(":COD_PESSOA"=>$param_cod_pessoa_col);
        $stmt= $pdo->prepare($sql);
        $stmt->execute($parametros_sql);
        if( $stmt->rowCount() == 0 )
        {
          $vCamposObrigatorios = "<font color='red font-size: 14px'>Exclusão de pessoa não foi concluída. Tente novamente.</font>";
        }
        else
        {
          echo("<script language='Javascript'>window.location = 'lista_usuario_sistema.php'</script>");
        }
      }
    } 
    catch (PDOException $e) 
    {
      $e->getMessage();
      $vErroCodigo = $vErroCodigo ."Exclusão de pessoa. Erro: $e <br>";
    };
  }
	elseif(isset($_REQUEST['bt_voltar']))
  { 
    echo("<script language='Javascript'>window.location = 'lista_usuario_sistema.php'</script>");
  }
	elseif(isset($_REQUEST['bt_gravar']))
  {   
    if (!empty($_REQUEST['cp_nome_registro'])) 	{ $param_nome_registro = trim($_REQUEST['cp_nome_registro']); };
    if (!empty($_REQUEST['cp_nome_social'])) 		{ $param_nome_social = trim($_REQUEST['cp_nome_social']); };
    if (!empty($_REQUEST['cp_data_nasc'])) 			{ $param_data_nasc = trim($_REQUEST['cp_data_nasc']); $param_data_nasc_gv = data_sistema(trim($_REQUEST['cp_data_nasc']));};
    if (!empty($_REQUEST['cp_cpf'])) 					  { $param_cpf = so_numero(trim($_REQUEST['cp_cpf'])); };
    if (!empty($_REQUEST['cp_ddd01'])) 					{ $param_ddd01 = trim($_REQUEST['cp_ddd01']); };
    if (!empty($_REQUEST['cp_telefone01'])) 		{ $param_telefone01 = trim($_REQUEST['cp_telefone01']); };
    if (!empty($_REQUEST['cp_tipo01'])) 				{ $param_tipo01 = trim($_REQUEST['cp_tipo01']); };
    if (!empty($_REQUEST['cp_ddd02'])) 					{ $param_ddd02 = trim($_REQUEST['cp_ddd02']); };
    if (!empty($_REQUEST['cp_telefone02'])) 		{ $param_telefone02 = trim($_REQUEST['cp_telefone02']); };
    if (!empty($_REQUEST['cp_tipo02'])) 				{ $param_tipo02 = trim($_REQUEST['cp_tipo02']); } else { $param_tipo02 = null; };
    if (!empty($_REQUEST['cp_cep'])) 					  { $param_cep = so_numero(trim($_REQUEST['cp_cep'])); };
    if (!empty($_REQUEST['cp_uf'])) 					  { $param_uf = trim($_REQUEST['cp_uf']); };
    if (!empty($_REQUEST['cp_cidade'])) 				{ $param_cidade = trim($_REQUEST['cp_cidade']); };
    if (!empty($_REQUEST['cp_logradouro'])) 		{ $param_logradouro = trim($_REQUEST['cp_logradouro']); };
    if (!empty($_REQUEST['cp_numero'])) 				{ $param_numero = so_numero(trim($_REQUEST['cp_numero'])); };
    if (!empty($_REQUEST['cp_bairro'])) 				{ $param_bairro = trim($_REQUEST['cp_bairro']); };
    if (!empty($_REQUEST['cp_complemento'])) 		{ $param_complemento = trim($_REQUEST['cp_complemento']); };
    if (!empty($_REQUEST['cp_caixa_postal'])) 	{ $param_caixa_postal = so_numero(trim($_REQUEST['cp_caixa_postal'])); };
    
    if (!empty($_REQUEST['cp_email'])) 					{ $param_email = trim($_REQUEST['cp_email']); };
    if (!empty($_REQUEST['cp_tipo_email'])) 		{ $param_tipo_email = trim($_REQUEST['cp_tipo_email']); };
    if (!empty($_REQUEST['cp_senha'])) 		      { $param_senha = trim($_REQUEST['cp_senha']); };
    if (!empty($_REQUEST['cp_conf_senha'])) 		{ $param_conf_senha = trim($_REQUEST['cp_conf_senha']); };
       
    $vSeparador = "";
    if (empty($param_nome_registro)) { $vCamposObrigatorios = "Nome de Registro"; $vSeparador = ", "; };
    if (empty($param_nome_social))   { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Nome de Registro"; $vSeparador = ", "; };
    
    if (empty($param_ddd01))         { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."DDD 01"; $vSeparador = ", "; };
    if (empty($param_telefone01))    { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Telefone 01"; $vSeparador = ", "; };
    
    if (empty($param_email))         { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."E-mail"; $vSeparador = ", "; };
    if (empty($param_senha))         { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Senha"; $vSeparador = ", "; };
    if (empty($param_conf_senha))    { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Confirmação de Senha"; $vSeparador = ", "; };
    
    if (!empty($vCamposObrigatorios))
    {
      $vCamposObrigatorios = $vCamposObrigatorios ." são campos obrigatório(s)."; 
      
      if (!empty($param_senha) and !empty($param_conf_senha))
      {
        if ($param_senha <> $param_conf_senha)
        {
          $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."<br>Senha e Confirmação de Senha não podem ser diferente.";
        }
      }
      $vCamposObrigatorios = "<font color='red' font-size: 14px>". $vCamposObrigatorios ."</font>"; 
    }
    else
    {
      if (!empty($param_senha) and !empty($param_conf_senha))
      {
        if ($param_senha <> $param_conf_senha)
        {
          $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."<font color='red' font-size: 14px>Senha e Confirmação de Senha não podem ser diferente.</font>";
        }
      }
    }
    
    if (empty($vCamposObrigatorios))
    {
      if (!empty($param_data_nasc))
      {
      	$vet_data = explode("/",$param_data_nasc);
      	$param_data_nasc_formatada = $vet_data[2]."-".$vet_data[1]."-".$vet_data[0];
      }
      if (!empty($param_cpf))
      {
      	$param_cpf_numeros = preg_replace("/[^0-9]/", "", $param_cpf);
      }
      if (!empty($param_cpf))
      {
      	$param_cep_numeros = preg_replace("/[^0-9]/", "", $param_cep);
      }
     
      try 
      { // CADASTRO DE PESSOA
        $sql = "insert into pessoa
                (alteracao, id_usuario_alteracao, nome_oficial, nome_social, 
                 cpf, data_nascimento, ddd_01, telefone_01, ddd_02, telefone_02, cep, 
                 cidade, uf, logradouro, numero, caixa_postal, bairro, complemento, email)
                values (now(), :ID_USER_EXECUCAO, :NOME_OFICIAL, :NOME_SOCIAL, 
                        :CPF, :DATA_NASCIMENTO, :DDD_01, :TELEFONE_01, :DDD_02, :TELEFONE_02, :CEP, 
                        :CIDADE, :UF, :LOGRADOURO, :NUMERO, :CAIXA_POSTAL, :BAIRRO, :COMPLEMENTO, :EMAIL_01)";
        $parametros_sql = array(":ID_USER_EXECUCAO"=>3,
                                ":NOME_OFICIAL"=>$param_nome_registro, 
                                ":NOME_SOCIAL"=>$param_nome_social, 
                                ":CPF"=>$param_cpf, 
                                ":DATA_NASCIMENTO"=>$param_data_nasc_gv, 
                                ":DDD_01"=>$param_ddd01, 
                                ":TELEFONE_01"=>$param_telefone01, 
                                ":DDD_02"=>$param_ddd02, 
                                ":TELEFONE_02"=>$param_telefone02, 
                                ":CEP"=>$param_cep, 
                                ":CIDADE"=>$param_cidade, 
                                ":UF"=>$param_uf, 
                                ":LOGRADOURO"=>$param_logradouro, 
                                ":NUMERO"=>$param_numero, 
                                ":CAIXA_POSTAL"=>$param_caixa_postal, 
                                ":BAIRRO"=>$param_bairro, 
                                ":COMPLEMENTO"=>$param_complemento, 
                                ":EMAIL_01"=>$param_email);
        $stmt= $pdo->prepare($sql);
        $stmt->execute($parametros_sql);
        $vCodPessoa = $pdo->lastInsertId('cod_pessoa');
        
        if (!empty($vCodPessoa) and $vCodPessoa > 0)
        { // CADASTRO DE USUARIO DA PESSOA
          $sql = "insert into usuario
                  (alteracao, id_usuario_alteracao, usuario, senha, tipo_usuario, cod_pessoa)
                  values (now(), :ID_USER_EXECUCAO, :USUARIO, :SENHA, :TIPO_USUARIO, :COD_PESSOA)";
          $parametros_sql = array(":ID_USER_EXECUCAO"=>3,
                                  ":USUARIO"=> 'usuario'. $vCodPessoa, 
                                  ":SENHA"=>$param_senha, 
                                  ":TIPO_USUARIO"=>"CL",
                                  ":COD_PESSOA"=>$vCodPessoa);
          $stmt= $pdo->prepare($sql);
          $stmt->execute($parametros_sql);
          $vCodUsuario = $pdo->lastInsertId('cod_usuario');
          
          if (!empty($vCodUsuario) and $vCodUsuario > 0)
          {
            echo("<font color='blue font-size: 16px'>Usuário cadastrado com sucesso.</font>");
            echo("<script language='Javascript'>window.location = 'cadastro_acesso_colaborador.php?param_cod_pessoa_col=". $vCodPessoa ."'</script>");
          }
          else
          {
            $vCamposObrigatorios = "<font color='red font-size: 14px'>Cadastro não foi concluído. Tente novamente.</font>";
          }
        }
        else
        {
          $vCamposObrigatorios = "<font color='red font-size: 14px'>Cadastro não foi concluído. Tente novamente.</font>";
        }
      } 
      catch (PDOException $e) 
      {
        $e->getMessage();
        $vErroCodigo = $vErroCodigo ."Cadastro de usuário. Erro: $e <br>";
      };
    };
	}
  elseif(isset($_REQUEST['bt_alterar']))
  {   
    if (!empty($_REQUEST['cp_nome_registro'])) 	{ $param_nome_registro = trim($_REQUEST['cp_nome_registro']); };
    if (!empty($_REQUEST['cp_nome_social'])) 		{ $param_nome_social = trim($_REQUEST['cp_nome_social']); };
    if (!empty($_REQUEST['cp_data_nasc'])) 			{ $param_data_nasc = trim($_REQUEST['cp_data_nasc']); $param_data_nasc_gv = data_sistema(trim($_REQUEST['cp_data_nasc']));};
    if (!empty($_REQUEST['cp_cpf'])) 					  { $param_cpf = so_numero(trim($_REQUEST['cp_cpf'])); };
    if (!empty($_REQUEST['cp_ddd01'])) 					{ $param_ddd01 = trim($_REQUEST['cp_ddd01']); };
    if (!empty($_REQUEST['cp_telefone01'])) 		{ $param_telefone01 = trim($_REQUEST['cp_telefone01']); };
    if (!empty($_REQUEST['cp_tipo01'])) 				{ $param_tipo01 = trim($_REQUEST['cp_tipo01']); };
    if (!empty($_REQUEST['cp_ddd02'])) 					{ $param_ddd02 = trim($_REQUEST['cp_ddd02']); };
    if (!empty($_REQUEST['cp_telefone02'])) 		{ $param_telefone02 = trim($_REQUEST['cp_telefone02']); };
    if (!empty($_REQUEST['cp_tipo02'])) 				{ $param_tipo02 = trim($_REQUEST['cp_tipo02']); } else { $param_tipo02 = null; };
    if (!empty($_REQUEST['cp_cep'])) 					  { $param_cep = so_numero(trim($_REQUEST['cp_cep'])); };
    if (!empty($_REQUEST['cp_uf'])) 					  { $param_uf = trim($_REQUEST['cp_uf']); };
    if (!empty($_REQUEST['cp_cidade'])) 				{ $param_cidade = trim($_REQUEST['cp_cidade']); };
    if (!empty($_REQUEST['cp_logradouro'])) 		{ $param_logradouro = trim($_REQUEST['cp_logradouro']); };
    if (!empty($_REQUEST['cp_numero'])) 				{ $param_numero = so_numero(trim($_REQUEST['cp_numero'])); };
    if (!empty($_REQUEST['cp_bairro'])) 				{ $param_bairro = trim($_REQUEST['cp_bairro']); };
    if (!empty($_REQUEST['cp_complemento'])) 		{ $param_complemento = trim($_REQUEST['cp_complemento']); };
    if (!empty($_REQUEST['cp_caixa_postal'])) 	{ $param_caixa_postal = so_numero(trim($_REQUEST['cp_caixa_postal'])); };
    
    if (!empty($_REQUEST['cp_email'])) 					{ $param_email = trim($_REQUEST['cp_email']); };
    if (!empty($_REQUEST['cp_tipo_email'])) 		{ $param_tipo_email = trim($_REQUEST['cp_tipo_email']); };
    if (!empty($_REQUEST['cp_senha'])) 		      { $param_senha = trim($_REQUEST['cp_senha']); };
    if (!empty($_REQUEST['cp_conf_senha'])) 		{ $param_conf_senha = trim($_REQUEST['cp_conf_senha']); };
       
    $vSeparador = "";
    if (empty($param_nome_registro)) { $vCamposObrigatorios = "Nome de Registro"; $vSeparador = ", "; };
    if (empty($param_nome_social))   { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Nome de Registro"; $vSeparador = ", "; };
    
    if (empty($param_ddd01))         { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."DDD 01"; $vSeparador = ", "; };
    if (empty($param_telefone01))    { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Telefone 01"; $vSeparador = ", "; };
    
    if (empty($param_email))         { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."E-mail"; $vSeparador = ", "; };
    if (empty($param_senha))         { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Senha"; $vSeparador = ", "; };
    if (empty($param_conf_senha))    { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Confirmação de Senha"; $vSeparador = ", "; };
    
    if (!empty($vCamposObrigatorios))
    {
      $vCamposObrigatorios = $vCamposObrigatorios ." são campos obrigatório(s)."; 
      
      if (!empty($param_senha) and !empty($param_conf_senha))
      {
        if ($param_senha <> $param_conf_senha)
        {
          $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."<br>Senha e Confirmação de Senha não podem ser diferente.";
        }
      }
      $vCamposObrigatorios = "<font color='red' font-size: 14px>". $vCamposObrigatorios ."</font>"; 
    }
    else
    {
      if (!empty($param_senha) and !empty($param_conf_senha))
      {
        if ($param_senha <> $param_conf_senha)
        {
          $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."<font color='red' font-size: 14px>Senha e Confirmação de Senha não podem ser diferente.</font>";
        }
      }
    }
    
    if (empty($vCamposObrigatorios))
    {
      if (!empty($param_data_nasc))
      {
      	$vet_data = explode("/",$param_data_nasc);
      	$param_data_nasc_formatada = $vet_data[2]."-".$vet_data[1]."-".$vet_data[0];
      }
      if (!empty($param_cpf))
      {
      	$param_cpf_numeros = preg_replace("/[^0-9]/", "", $param_cpf);
      }
      if (!empty($param_cpf))
      {
      	$param_cep_numeros = preg_replace("/[^0-9]/", "", $param_cep);
      }
     
      try 
      { // CADASTRO DE PESSOA
        $sql = "update pessoa
                   set alteracao = now(),
                       id_usuario_alteracao = :ID_USER_EXECUCAO,
                       nome_oficial = :NOME_OFICIAL,
                       nome_social = :NOME_SOCIAL,
                       cpf = :CPF,
                       data_nascimento = :DATA_NASCIMENTO,
                       ddd_01 = :DDD_01,
                       telefone_01 = :TELEFONE_01,
                       ddd_02 = :DDD_02,
                       telefone_02 = :TELEFONE_02,
                       cep = :CEP,
                       cidade = :CIDADE,
                       uf = :UF,
                       logradouro = :LOGRADOURO,
                       numero = :NUMERO,
                       caixa_postal = :CAIXA_POSTAL,
                       bairro = :BAIRRO,
                       complemento = :COMPLEMENTO,
                       email = :EMAIL
                where cod_pessoa = :COD_PESSOA";
        $parametros_sql = array(":ID_USER_EXECUCAO"=>$_SESSION['param_cod_usuario'],
                                ":NOME_OFICIAL"=>$param_nome_registro,
                                ":NOME_SOCIAL"=>$param_nome_social,
                                ":CPF"=>$param_cpf,
                                ":DATA_NASCIMENTO"=>$param_data_nasc_gv,
                                ":DDD_01"=>$param_ddd01,
                                ":TELEFONE_01"=>$param_telefone01,
                                ":DDD_02"=>$param_ddd02,
                                ":TELEFONE_02"=>$param_telefone02,
                                ":CEP"=>$param_cep,
                                ":CIDADE"=>$param_cidade,
                                ":UF"=>$param_uf,
                                ":LOGRADOURO"=>$param_logradouro,
                                ":NUMERO"=>$param_numero,
                                ":CAIXA_POSTAL"=>$param_caixa_postal,
                                ":BAIRRO"=>$param_bairro,
                                ":COMPLEMENTO"=>$param_complemento,
                                ":EMAIL"=>$param_email,
                                ":COD_PESSOA"=>$param_cod_pessoa_col);
        $stmt= $pdo->prepare($sql);
        $stmt->execute($parametros_sql);
        if( $stmt->rowCount() == 0 )
        {
          $vCamposObrigatorios = "<font color='red font-size: 14px'>Atualização não foi concluída. Tente novamente.</font>";
        }
        else
        {
          $sql = "update usuario
                     set alteracao = now(),
                         id_usuario_alteracao = :ID_USER_EXECUCAO,
                         senha = :SENHA
                  where cod_pessoa = :COD_PESSOA";
          $parametros_sql = array(":ID_USER_EXECUCAO"=>$_SESSION['param_cod_usuario'],
                                  ":SENHA"=>$param_senha,
                                  ":COD_PESSOA"=>$param_cod_pessoa_col);
          $stmt= $pdo->prepare($sql);
          $stmt->execute($parametros_sql);
          if( $stmt->rowCount() == 0 )
          {
            $vCamposObrigatorios = "<font color='red font-size: 14px'>Atualização não foi concluída. Tente novamente.</font>";
          }
          else
          {
            $vCamposObrigatorios = "<font color='red font-size: 14px'>Atualizado com sucesso.</font>";
          }
        }
      } 
      catch (PDOException $e) 
      {
        $e->getMessage();
        $vErroCodigo = $vErroCodigo ."Cadastro de usuário. Erro: $e <br>";
      };
      
    };
	}
  else
  {  
    if (!empty($param_cod_pessoa_col))
    { // BUSCA DADOS DA BASE    
      try 
      {
        $sql = "select DATE_FORMAT(p.alteracao,'%d/%m/%Y %H:%i') as alteracao,
                       pa.nome_social as usuario_alteracao,
                       p.nome_oficial,
                       p.nome_social,
                       p.cpf,
                       DATE_FORMAT(p.data_nascimento,'%d/%m/%Y') as data_nascimento,
                       p.ddd_01,
                       p.telefone_01,
                       p.ddd_02,
                       p.telefone_02,
                       p.cep,
                       p.cidade,
                       p.uf,
                       p.logradouro,
                       p.numero,
                       p.caixa_postal,
                       p.bairro,
                       p.complemento,
                       p.email,
                       u.usuario,
                       u.senha
                  from pessoa p
                        inner join usuario u on (u.cod_pessoa = p.cod_pessoa)
                        left join usuario ua on (ua.cod_usuario = p.id_usuario_alteracao)
                        left join pessoa pa on (pa.cod_pessoa = ua.cod_pessoa)
                        where p.cod_pessoa = :COD_PESSOA";
        $parametros_sql = array(":COD_PESSOA"=>$param_cod_pessoa_col);
        $stmt= $pdo->prepare($sql);
        $stmt->execute($parametros_sql);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!empty($result["nome_oficial"]))
        {        
          $param_nome_registro = $result["nome_oficial"];
          $param_nome_social = $result["nome_social"];
          $param_data_nasc = $result["data_nascimento"];
          $param_cpf = $result["cpf"];
          $param_ddd01 = $result["ddd_01"];
          $param_telefone01 = $result["telefone_01"];
          $param_ddd02 = $result["ddd_02"];
          $param_telefone02 = $result["telefone_02"];
          $param_cep = $result["cep"];
          $param_cidade = $result["cidade"];
          $param_uf = $result["uf"];
          $param_logradouro = $result["logradouro"];
          $param_numero = $result["numero"];
          $param_caixa_postal = $result["caixa_postal"];
          $param_bairro = $result["bairro"];
          $param_complemento = $result["complemento"];
          $param_email = $result["email"];
          $param_senha = $result["senha"];
          $param_conf_senha = $result["senha"];
          $LblUsuario = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Usuário:</b> ". $result["usuario"];
          
          $vUltimoAlterador = "Ultima alteração foi realizada em ". $result["alteracao"] ." por ". $result["usuario_alteracao"];
        };
        
      } catch(PDOException $e) {
        $e->getMessage();
        echo "<span class='fonte_doze_negrito_erro'>[ Erro $e ]</span>";
        exit;
      };
    }
  };
?>

<!DOCTYPE>
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Cadastro</title>
    <script type="text/javascript" src="./js/jquery.js"></script>
    <script type="text/javascript" src="./js/jquery.maskedinput.js"/></script>
    <script>
    function Carrega_Formulario()
    {
      $("#div_cabecalho").load("cabecalho_ajax.php", {param_funcao: 'carregar'});
    }
    
    function ValidarUsuario()
    {
      $("#div_cabecalho").load("cabecalho_ajax.php", {param_funcao: 'validar_acesso', param_email: $("#var_email").val(), param_senha: $("#var_senha").val()});
    }
    
    $(document).ready(function(){
      $("#cp_cpf").mask("999.999.999-99");
      $("#cp_cep").mask("99.999-999");
    });
    
    function mascaraData( campo, e )
    {
      var kC = (document.all) ? event.keyCode : e.keyCode;
      var data = campo.value;
      
      if( kC!=8 && kC!=46 )
      {
        if( data.length==2 )
        {
          campo.value = data += '/';
        }
        else if( data.length==5 )
        {
          campo.value = data += '/';
        }
        else
          campo.value = data;
      }
    }
    
    function validacaoEmail(field) 
    {
      usuario = field.value.substring(0, field.value.indexOf("@"));
      dominio = field.value.substring(field.value.indexOf("@")+ 1, field.value.length);

      if ((usuario.length >=1) &&
          (dominio.length >=3) &&
          (usuario.search("@")==-1) &&
          (dominio.search("@")==-1) &&
          (usuario.search(" ")==-1) &&
          (dominio.search(" ")==-1) &&
          (dominio.search(".")!=-1) &&
          (dominio.indexOf(".") >=1)&&
          (dominio.lastIndexOf(".") < dominio.length - 1)) {
        document.getElementById("span_msg").innerHTML="";
      }
      else
      {
        document.getElementById("span_msg").innerHTML="<font style='color: #FF0000;'>E-mail inválido</font>";
      }
    }
    
    function comparar_senha()
    {
      var vSenha = document.getElementById("cp_senha").value;
      var vConferirSenha = document.getElementById("cp_conf_senha").value;
      if (vSenha != vConferirSenha) 
      {
        document.getElementById("span_msg").innerHTML = "<font style='color: #FF0000;'>Senha e Confirmação de senha estão diferentes.</font>";
      }
      else
      {
        document.getElementById("span_msg").innerHTML = "";
      }
    }
    
    function comparar_email()
    {
      var vSenha = document.getElementById("cp_email").value;
      var vConferirSenha = document.getElementById("cp_conf_email").value;
      if (vSenha != vConferirSenha) 
      {
        document.getElementById("span_msg").innerHTML = "<font style='color: #FF0000;'>E-mail e Confirmação de E-mail estão diferentes.</font>";
      }
      else
      {
        document.getElementById("span_msg").innerHTML = "";
      }
    }
    
    function BuscaCPF()
    {
      if (document.getElementById("cp_cpf").value != "") 
      {
        $.getJSON("cadastro_ajax.php", {param_funcao: "busca_cpf_col", param_cpf: document.getElementById("cp_cpf").value}, function(data){
          if (data[0] != 0)
          {
            document.getElementById("span_msg").innerHTML = "<font color='red'>CPF " + document.getElementById("cp_cpf").value + " já consta no cadastro.</font>";
          };
        });
      };
    }
    
    function BuscaEmail(vReferencia)
    {
      if (document.getElementById("cp_email").value != "") 
      {
        $.getJSON("cadastro_ajax.php", {param_funcao: "busca_email_col", param_email: document.getElementById("cp_email").value, param_referencia: vReferencia}, function(data){
          if (data[0] != 0)
          {
            document.getElementById("span_msg").innerHTML = "<font color='red'>E-mail " + document.getElementById("cp_email").value + " já consta no cadastro.</font>";
          };
        });
      };
    }
    
    function copia_nome()
    {
      if ($("#cp_nome_social").val() == "")
      {
        document.getElementById("cp_nome_social").value = $("#cp_nome_registro").val();
      }
    }
    
    function proximo_campo(vCampo)
    {
      if (vCampo == "cp_numero")
      {
        if ($("#cp_bairro").val() != "")
        {
          document.getElementById("cp_email").focus();
        }
      }
    }   
    </script>
    <style type="text/css">
	  @import "css.css";
    </style>
  </head>
  <body onLoad="Carrega_Formulario()">
    <div id="div_cabecalho"></div>
    <table width="100%" border="0" align="center" background="./img/fundo_principal.png">
      <tr>
        <td height="135px">
          <table width="1000px" border="0" align="center">
            <tr>
              <td class="titulo_azul_20" height="50px" colspan="2"><br><br>Cadastro de Acesso<br><br></td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
    <center><br>
    <form id="FA" name="FA" method="post" action="cadastro_acesso_colaborador.php">
      <table width="860px" border="0" cellspacing="2" cellpadding="2">
				<tr>
          <td class="fonte12_esq"><b>Nome de Registro <span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="8"><input type="text" name="cp_nome_registro" id="cp_nome_registro" placeholder="Nome de Registro" value="<?php echo($param_nome_registro); ?>" size="97" onBlur="copia_nome();"></td>
        </tr>
				<tr>
          <td class="fonte12_esq"><b>Nome Social <span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="8"><input type="text" name="cp_nome_social" id="cp_nome_social" placeholder="Nome Social" value="<?php echo($param_nome_social); ?>" size="97"></td>
        </tr>
				<tr>
          <td class="fonte12_esq"><b>Nascimento <span style="color:red">*</span></b></td>
          <td class="fonte12_esq"><input type="text" name="cp_data_nasc" id="cp_data_nasc" placeholder="DD/MM/AAAA" value="<?php echo($param_data_nasc); ?>" size="10" maxlength="10" onkeypress="mascaraData( this, event )"></td>
          <td class="fonte12_esq"><b>CPF <span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="5"><input type="text" name="cp_cpf" id="cp_cpf" placeholder="CPF" value="<?php echo($param_cpf); ?>" size="11" maxlength="10" onBlur="BuscaCPF()"></td>
        </tr>  

				<tr>
          <td class="fonte12_esq"><b>DDD <span style="color:red">*</span></b></td>
          <td class="fonte12_esq"><input type="text" name="cp_ddd01" id="cp_ddd01" placeholder="DDD" value="<?php echo($param_ddd01); ?>" size="2" maxlength="2"></td>
          <td class="fonte12_esq"><b>Telefone <span style="color:red">*</span></b></td>
          <td class="fonte12_esq"><input type="text" name="cp_telefone01" id="cp_telefone01" placeholder="Telefone" value="<?php echo($param_telefone01); ?>" size="11" maxlength="9"></td>
          <td class="fonte12_esq"><b>DDD</b></td>
          <td class="fonte12_esq">
            <input type="text" name="cp_ddd02" id="cp_ddd02" placeholder="DDD" value="<?php echo($param_ddd02); ?>" size="2" maxlength="2">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Telefone</b>&nbsp;&nbsp;&nbsp;
            <input type="text" name="cp_telefone02" id="cp_telefone02" placeholder="Telefone" value="<?php echo($param_telefone02); ?>" size="11" maxlength="9">
          </td>
        </tr>

				<tr>
          <td class="fonte12_esq"><b>CEP <span style="color:red">*</span></b></td>
          <td class="fonte12_esq"><input type="text" name="cp_cep" id="cp_cep" placeholder="CEP" value="<?php echo($param_cep); ?>" size="8"></td>
          <td class="fonte12_esq"><b>Estado <span style="color:red">*</span></b></td>
          <td class="fonte12_esq">
            <select name='cp_uf' id='cp_uf'>
              <option value='AC' <?php if ('AC' == $param_uf) { ECHO("SELECTED"); }; ?>>Acre</option>
              <option value='AL' <?php if ('AL' == $param_uf) { ECHO("SELECTED"); }; ?>>Alagoas</option>
              <option value='AP' <?php if ('AP' == $param_uf) { ECHO("SELECTED"); }; ?>>Amapa</option>
              <option value='AM' <?php if ('AM' == $param_uf) { ECHO("SELECTED"); }; ?>>Amazonas</option>
              <option value='BA' <?php if ('BA' == $param_uf) { ECHO("SELECTED"); }; ?>>Bahia</option>
              <option value='CE' <?php if ('CE' == $param_uf) { ECHO("SELECTED"); }; ?>>CEARA</option>
              <option value='DF' <?php if ('DF' == $param_uf) { ECHO("SELECTED"); }; ?>>Distrito Federal</option>
              <option value='ES' <?php if ('ES' == $param_uf) { ECHO("SELECTED"); }; ?>>Espirito Santo</option>
              <option value='GO' <?php if ('GO' == $param_uf) { ECHO("SELECTED"); }; ?>>Goias</option>
              <option value='MA' <?php if ('MA' == $param_uf) { ECHO("SELECTED"); }; ?>>Maranhao</option>
              <option value='MT' <?php if ('MT' == $param_uf) { ECHO("SELECTED"); }; ?>>Mato Grosso</option>
              <option value='MS' <?php if ('MS' == $param_uf) { ECHO("SELECTED"); }; ?>>Mato Grosso do Sul</option>
              <option value='MG' <?php if ('MG' == $param_uf) { ECHO("SELECTED"); }; ?>>Minas Gerais</option>
              <option value='PA' <?php if ('PA' == $param_uf) { ECHO("SELECTED"); }; ?>>Para</option>
              <option value='PB' <?php if ('PB' == $param_uf) { ECHO("SELECTED"); }; ?>>Paraiba</option>
              <option value='PR' <?php if ('PR' == $param_uf) { ECHO("SELECTED"); }; ?>>Parana</option>
              <option value='PE' <?php if ('PE' == $param_uf) { ECHO("SELECTED"); }; ?>>Pernambuco</option>
              <option value='PI' <?php if ('PI' == $param_uf) { ECHO("SELECTED"); }; ?>>Piaui</option>
              <option value='RJ' <?php if ('RJ' == $param_uf) { ECHO("SELECTED"); }; ?>>Rio de Janeiro</option>
              <option value='RN' <?php if ('RN' == $param_uf) { ECHO("SELECTED"); }; ?>>Rio Grande do Norte</option>
              <option value='RS' <?php if ('RS' == $param_uf) { ECHO("SELECTED"); }; ?>>Rio Grande do Sul</option>
              <option value='RO' <?php if ('RO' == $param_uf) { ECHO("SELECTED"); }; ?>>Rondonia</option>
              <option value='RR' <?php if ('RR' == $param_uf) { ECHO("SELECTED"); }; ?>>Roraima</option>
              <option value='SC' <?php if ('SC' == $param_uf) { ECHO("SELECTED"); }; ?>>Santa Catarina</option>
              <option value='SP' <?php if ('SP' == $param_uf) { ECHO("SELECTED"); }; ?>>São Paulo</option>
              <option value='SE' <?php if ('SE' == $param_uf) { ECHO("SELECTED"); }; ?>>Sergipe</option>
              <option value='TO' <?php if ('TO' == $param_uf) { ECHO("SELECTED"); }; ?>>Tocantins</option>
            </select>
          </td>
          <td class="fonte12_esq"><b>Cidade <span style="color:red">*</span></b></td>
          <td class="fonte12_esq"><input type="text" name="cp_cidade" id="cp_cidade" placeholder="Cidade" value="<?php echo($param_cidade); ?>" size="30"></td>
        </tr>

				<tr>
          <td class="fonte12_esq"><b>Logradouro</b></td>
          <td class="fonte12_esq" colspan="3"><input type="text" name="cp_logradouro" id="cp_logradouro" placeholder="Logradouro" value="<?php echo($param_logradouro); ?>" size="40"></td>
          <td class="fonte12_esq"><b>Número</b></td>
          <td class="fonte12_esq">
            <input type="text" name="cp_numero" id="cp_numero" placeholder="Numero" value="<?php echo($param_numero); ?>" size="5" onBlur="proximo_campo('cp_numero');">
            &nbsp;&nbsp;&nbsp;&nbsp;<b>Caixa Postal</b>&nbsp;&nbsp;&nbsp;
            <input type="text" name="cp_caixa_postal" id="cp_caixa_postal" placeholder="Numero" value="<?php echo($param_caixa_postal); ?>" size="5">
          </td>
        </tr>
				<tr>
          <td class="fonte12_esq"><b>Bairro</b></td>
          <td class="fonte12_esq" colspan="3"><input type="text" name="cp_bairro" id="cp_bairro" placeholder="Bairro" value="<?php echo($param_bairro); ?>" size="40"></td>
          <td class="fonte12_esq"><b>Complemento</b></td>
          <td class="fonte12_esq"><input type="text" name="cp_complemento" id="cp_complemento" placeholder="Complemento" value="<?php echo($param_complemento); ?>" size="30"></td>
        </tr>

				<tr>
          <td class="fonte12_esq"><b>E-mail <span style="color:red">*</span></b></td>
<?php if ($param_cod_pessoa_col == "0") { ?>
          <td class="fonte12_esq" colspan="3"><input type="text" name="cp_email" id="cp_email" placeholder="E-mail" value="<?php echo($param_email); ?>" size="40" onBlur="BuscaEmail(0)" onchange="comparar_email()"></td>
          <td class="fonte12_esq"><b>Conf. de E-mail <span style="color:red">*</span></b></td>
          <td class="fonte12_esq"><input type="text" name="cp_conf_email" id="cp_conf_email" placeholder="Confirmação de E-mail" value="<?php echo($param_email); ?>" size="30" onBlur="ConfEmail(0)" onchange="comparar_email()"></td>
<?php } else { ?>
          <td class="fonte12_esq" colspan="3"><input type="text" name="cp_email" id="cp_email" placeholder="E-mail" value="<?php echo($param_email); ?>" size="40" onBlur="BuscaEmail(<?PHP echo($param_cod_pessoa_col); ?>)"></td>
          <td class="fonte12_esq" colspan="2"></td>
<?php } ?>
        </tr>
				<tr>
          <td class="fonte12_esq"><b>Senha <span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="2"><input type="password" name="cp_senha" id="cp_senha" value="<?php echo($param_senha); ?>" size="15" minlength="6" onchange="comparar_senha()"></td>
          <td class="fonte12_esq"><b>Confirmação de Senha <span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="2"><input type="password" name="cp_conf_senha" id="cp_conf_senha" value="<?php echo($param_conf_senha); ?>" size="15" minlength="6" onchange="comparar_senha()"><span id="span_msg_senha"></span><?php echo($LblUsuario); ?></td>
        </tr>
				<tr>
          <td class="fonte14" colspan="6"><span id="span_msg"><?php echo($vCamposObrigatorios); ?></span></td>
        </tr>
				<tr>
          <td class="fonte14" colspan="6">
<?php if ($param_cod_pessoa_col == "0") { ?>
            <input type="submit" class="button_padrao" name="bt_gravar" value="&nbsp;&nbsp;Gravar&nbsp;&nbsp;">
<?php } else { ?>
            <input type="submit" class="button_padrao" name="bt_alterar" value="&nbsp;&nbsp;Alterar&nbsp;&nbsp;">
<?php } ?>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="submit" class="button_padrao" name="bt_voltar" value="&nbsp;&nbsp;Voltar&nbsp;&nbsp;">
          </td>
        </tr>
      </table>
      <input type="hidden" id="param_cod_pessoa_col" name="param_cod_pessoa_col" value="<?PHP echo($param_cod_pessoa_col); ?>">
    </form>
    <?php echo($vErroCodigo); ?>
  </body>
</html>