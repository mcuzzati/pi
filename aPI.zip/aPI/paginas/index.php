<?php	
  if ( session_status() !== PHP_SESSION_ACTIVE )
  {
    session_start();
  }
  require_once("seg_conexao.php");
   
  try 
	{  
	  $pdo = connect();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	}
	catch(PDOException $e)
	{
		$e->getMessage();
		echo "<span class='fonte_doze_negrito_erro'>Conectando com Banco de Dados. [ Erro $e ]</span>";
		exit;
	};
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Vagas de Emprego</title>
<style type="text/css">
@import "css.css";
</style>
<script type="text/javascript" src="./js/jquery.maskedinput.js" ></script>
<script type="text/javascript" src="./js/jquery.js"></script>
<script type="text/javascript" src="./js/jquery.form.js"></script>
<script type="text/javascript" src="./js/jquery.selects.js"></script>
<script language="javascript">
  function Carrega_Formulario()
  {
    $("#div_cabecalho").load("cabecalho_ajax.php", {param_funcao: 'carregar'});
  }
  
  function ValidarUsuario()
  {
    $("#div_cabecalho").load("cabecalho_ajax.php", {param_funcao: 'validar_acesso', param_email: $("#var_email").val(), param_senha: $("#var_senha").val()});
  }
</script>
</head>
<body onLoad="Carrega_Formulario()">
  <center>
  <div id="div_cabecalho"></div> 
  <table width="100%" border="0" align="center" background="./img/fundo_principal.png">
    <tr>
      <td height="135px">
        <table width="1000px" border="0" align="center">
          <tr>
            <td class="titulo_azul_20" height="50px" colspan="2"><br><br>Oportunidade de Emprego<br><br></td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
  <br>
  <table width="1000px" border="0" cellspacing="0" cellpadding="0">
<?php  
  try 
  {
		$sql = "select v.empresa,
                   v.departamento,
                   v.descritivo_vaga,
                   v.conhecimento_necessario,
                   v.beneficios,
                   v.salario,
                   g1.grau_escolaridade as grau_escolaridade,
                   g2.grau_escolaridade as grau_escolaridade_minimo
              from vaga_emprego v
                    left join grau_escolaridade g1
                     on (g1.cod_grau_escolaridade = v.cod_grau_escolaridade)
                    left join grau_escolaridade g2
                     on (g2.cod_grau_escolaridade = v.cod_grau_escolaridade_minimo)
             where v.status = 'A'";
    //$parametros_sql = array(":pData"=>$vData);
    $stmt= $pdo->prepare($sql);
    $stmt->execute();
  }
  catch(PDOException $e)
  {
    $e->getMessage();
    echo "<span class='fonte_doze_negrito_erro'>[ Erro $e ]</span>";
    exit;
  };
  
  $vContadorVaga = 0;
  while ($result = $stmt->fetch(PDO::FETCH_ASSOC)) 
  {
    $vContadorVaga = ($vContadorVaga + 1);
    if ($vContadorVaga == 1)
    {
?>
    <tr height="40px">
      <td bgcolor="#a6bce8" class="titulo_padrao arredondamento_superior">Vagas Disponíveis</td>
    </tr>
<?php
    }
?>
    <tr height="40px">
      <td bgcolor="<?php echo($vCorLinha); ?>" class="fonte14_esq" colspan="5">
        <b>Empresa:</b> <?php echo($result["empresa"]); ?><br><br>
        <b>Departamento:</b> <?php echo($result["departamento"]); ?><br><br>
        <b>Descritivo:</b><br><?php echo($result["descritivo_vaga"]); ?><br><br>
        <b>Conhecimento Necessário:</b><br><?php echo($result["conhecimento_necessario"]); ?><br><br>
        <b>Beneficios:</b><br><?php echo($result["beneficios"]); ?><br><br>
        <b>Salário:</b> <?php echo($result["salario"]); ?><br><br>
        <b>Escolaridade:</b> <?php echo($result["grau_escolaridade"]); ?><br><br>
<?php   if (!empty($result["grau_escolaridade_minimo"])) { echo("<b>Escolaridade miníma:</b> ". $result["grau_escolaridade_minimo"] ."<br>"); }; ?>
      </td>
    </tr>
    <tr height="40px">
      <td bgcolor="<?php echo($vCorLinha); ?>" class="fonte14" colspan="5"><hr></td>
    </tr>
<?php
  };
  
  if ($vContadorVaga == 0)
  {
?>
    <tr height="40px">
      <td bgcolor="#a6bce8" class="titulo_padrao arredondamento_superior arredondamento_inferior">Nenhuma vaga disponpível no momento.</td>
    </tr>
<?php
  }
?>
  </table>
</body>
</html>
<?php
  $pdo = "";
?>