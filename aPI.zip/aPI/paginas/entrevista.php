<?PHP	
  session_start();
  if (!isset($_SESSION['param_usuario']) or $_SESSION['param_tipo_usuario'] <> "CL")
  { 
    session_destroy();
    echo("<script language='Javascript'>window.location = 'index.php'</script>");
  }
  
	if (!empty($_REQUEST['param_vaga_candidato'])) { $param_vaga_candidato = trim($_REQUEST['param_vaga_candidato']); } else { $param_vaga_candidato = "0"; };
  if (!empty($_REQUEST['param_cod_vaga'])) { $param_cod_vaga = trim($_REQUEST['param_cod_vaga']); } else { $param_cod_vaga = "0"; };
  
	require_once("seg_conexao.php");
  require_once("funcoes.php");
		
  try 
  {
    $pdo = connect();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  } catch(PDOException $e) {
    $e->getMessage();
    echo "<span class='fonte_doze_negrito_erro'>[ Erro $e ]</span>";
    exit;
  };
    
  $vErroCodigo = "";
    
  $param_resumo_intrevista = "";
  $param_aprovado = "";
  $param_data_entrevista = "";
  
  $vCamposObrigatorios = "";
  
  if(isset($_REQUEST['bt_voltar']))
  { 
    echo("<script language='Javascript'>window.location = 'lista_candidato_por_vaga.php?param_cod_vaga=". $param_cod_vaga ."'</script>");
  }
	elseif(isset($_REQUEST['bt_alterar']))
  {   
    if (!empty($_REQUEST['cp_resumo_intrevista'])) { $param_resumo_intrevista = trim($_REQUEST['cp_resumo_intrevista']); };
    if (!empty($_REQUEST['cp_aprovado'])) 		     { $param_aprovado = trim($_REQUEST['cp_aprovado']); };
    if (!empty($_REQUEST['cp_data_entrevista']))   { $param_data_entrevista = trim($_REQUEST['cp_data_entrevista']); $param_data_entrevista_gv = data_sistema(trim($_REQUEST['cp_data_entrevista']));};
       
    $vSeparador = "";
    if (empty($param_aprovado)) { $vCamposObrigatorios = "Situação"; $vSeparador = ", "; };
    
    if (!empty($vCamposObrigatorios))
    {
      $vCamposObrigatorios = $vCamposObrigatorios ." são campos obrigatório(s)."; 
      
      $vCamposObrigatorios = "<font color='red' font-size: 14px>". $vCamposObrigatorios ."</font>"; 
    }
    
    if (empty($vCamposObrigatorios))
    {
      try 
      { // CADASTRO DA ENTREVISTA
        $sql = "update vaga_emprego_x_elegivel
                   set alteracao = now(),
                       id_usuario_alteracao = :ID_USER_EXECUCAO,
                       entrevistar = :ENTREVISTAR,
                       resumo_entrevista = :RESUMO_ENTREVISTA,
                       aprovado = :APROVADO
                where cod_vaga_candidato = :COD_VAGA_CANDIDATO";
        $parametros_sql = array(":ID_USER_EXECUCAO"=>$_SESSION['param_cod_usuario'],
                                ":ENTREVISTAR"=>$param_data_entrevista_gv,
                                ":RESUMO_ENTREVISTA"=>$param_resumo_intrevista,
                                ":APROVADO"=>$param_aprovado,
                                ":COD_VAGA_CANDIDATO"=>$param_vaga_candidato);
        $stmt= $pdo->prepare($sql);
        $stmt->execute($parametros_sql);
        if( $stmt->rowCount() == 0 )
        {
          $vCamposObrigatorios = "<font color='red font-size: 14px'>Entrevista não foi concluído. Tente novamente.</font>";
        }
        else
        {
          $vCamposObrigatorios = "<font color='red font-size: 14px'>Entrevista atualizado com sucesso.</font>";
        }
      } 
      catch (PDOException $e) 
      {
        $e->getMessage();
        $vErroCodigo = $vErroCodigo ."Cadastro de Entrevista. Erro: $e <br>";
      };
    };
	}
  else
  {  
    if (!empty($_SESSION['param_cod_pessoa']))
    { // BUSCA DADOS DA BASE    
      try 
      {
        $sql = "select DATE_FORMAT(p.alteracao,'%d/%m/%Y %H:%i') as alteracao,
                       pa.nome_social as usuario_alteracao,
                       p.nome_oficial,
                       p.nome_social,
                       p.cpf,
                       DATE_FORMAT(p.data_nascimento,'%d/%m/%Y') as data_nascimento,
                       p.ddd_01,
                       p.telefone_01,
                       p.ddd_02,
                       p.telefone_02,
                       p.cep,
                       p.cidade,
                       p.uf,
                       p.logradouro,
                       p.numero,
                       p.caixa_postal,
                       p.bairro,
                       p.complemento,
                       p.email,
                       p.perfil_profissional,
                       p.experiencia_profissional,
                       g.grau_escolaridade as grau_escolaridade,
                       p.complemento_educacional,
                       p.referencia,
                       replace(p.salario_desejado,'.',',') as salario_desejado,
                       vae.aprovado,
                       p.cod_pessoa
                  from vaga_emprego_x_elegivel vae
                        inner join pessoa p on (p.cod_pessoa = vae.cod_pessoa_candidato)
                        left join grau_escolaridade g on (g.cod_grau_escolaridade = p.cod_grau_escolaridade)
                        left join usuario u on (u.cod_usuario = p.id_usuario_alteracao)
                        left join pessoa pa on (pa.cod_pessoa = u.cod_pessoa)
                 where vae.cod_vaga_candidato =  :COD_VAGA_CANDIDATO";
        $parametros_sql = array(":COD_VAGA_CANDIDATO"=>$param_vaga_candidato);
        $stmt= $pdo->prepare($sql);
        $stmt->execute($parametros_sql);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!empty($result["nome_oficial"]))
        {        
          $param_pessoa = $result["cod_pessoa"];
          $param_nome_registro = $result["nome_oficial"];
          $param_nome_social = $result["nome_social"];
          $param_data_nasc = $result["data_nascimento"];
          $param_cpf = $result["cpf"];
          $param_ddd01 = $result["ddd_01"];
          $param_telefone01 = $result["telefone_01"];
          $param_ddd02 = $result["ddd_02"];
          $param_telefone02 = $result["telefone_02"];
          $param_cep = $result["cep"];
          $param_cidade = $result["cidade"];
          $param_uf = $result["uf"];
          $param_logradouro = $result["logradouro"];
          $param_numero = $result["numero"];
          $param_caixa_postal = $result["caixa_postal"];
          $param_bairro = $result["bairro"];
          $param_complemento = $result["complemento"];
          $param_email = $result["email"];
          $param_perfil_profissional = $result["perfil_profissional"];
          $param_experiencia_profissional = $result["experiencia_profissional"];
          $param_grau_escolaridade = $result["grau_escolaridade"];
          $param_complemento_educacional = $result["complemento_educacional"];
          $param_referencia_profissional = $result["referencia"];
          $param_salario = $result["salario_desejado"];

          if ($result["aprovado"] == "P")
          {
            $vAprovadoPendente = "SELECTED";
            $vAprovadoSim = "";
            $vAprovadoNao = "";
          }
          elseif ($result["aprovado"] == "S")
          {
            $vAprovadoPendente = "";
            $vAprovadoSim = "SELECTED";
            $vAprovadoNao = "";
          }
          elseif ($result["aprovado"] == "N")
          {
            $vAprovadoPendente = "";
            $vAprovadoSim = "";
            $vAprovadoNao = "SELECTED";
          }
          
          $vUltimoAlterador = "Ultima alteração foi realizada em ". $result["alteracao"] ." por ". $result["usuario_alteracao"];
        };
        
      } catch(PDOException $e) {
        $e->getMessage();
        echo "<span class='fonte_doze_negrito_erro'>[ Erro $e ]</span>";
        exit;
      };
    }
  };
?>

<!DOCTYPE>
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Entrevista do Candidato</title>
    <script type="text/javascript" src="./js/jquery.js"></script>
    <script type="text/javascript" src="./js/jquery.maskedinput.js"/></script>
    <script>
      function Carrega_Formulario()
      {
        $("#div_cabecalho").load("cabecalho_ajax.php", {param_funcao: 'carregar'});
      }

      function mascaraData( campo, e )
      {
        var kC = (document.all) ? event.keyCode : e.keyCode;
        var data = campo.value;
        
        if( kC!=8 && kC!=46 )
        {
          if( data.length==2 )
          {
            campo.value = data += '/';
          }
          else if( data.length==5 )
          {
            campo.value = data += '/';
          }
          else
            campo.value = data;
        }
      }

      function Logof()
      {
        $("#div_cabecalho").load("cabecalho_ajax.php", {param_funcao: 'logof'});
      }
    </script>
    <style type="text/css">
	  @import "css.css";
    </style>
  </head>
  <body onLoad="Carrega_Formulario()">
    <div id="div_cabecalho"></div>
    <table width="100%" border="0" align="center" background="./img/fundo_principal.png">
      <tr>
        <td height="135px">
          <table width="1000px" border="0" align="center">
            <tr>
              <td class="titulo_azul_20" height="50px" colspan="2"><br><br>Entrevista do Candidato<br><br></td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
    <center><br>
    <form id="FA" name="FA" method="post" action="entrevista.php">
      <table width="860px" border="0" cellspacing="6" cellpadding="2">
				<tr>
          <td class="titulo_azul_esq_20" colspan="9" bgcolor="#ebebeb" height="40px">:: Candidato</td>
        </tr>
				<tr>
          <td class="fonte12_esq"><b>Nome de Registro <span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="8"><?php echo($param_nome_registro); ?></td>
        </tr>
				<tr>
          <td class="fonte12_esq"><b>Nome Social <span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="8"><?php echo($param_nome_social); ?></td>
        </tr>
        
				<tr>
          <td class="fonte12_esq"><b>Nascimento <span style="color:red">*</span></b></td>
          <td class="fonte12_esq"><?php echo($param_data_nasc); ?></td>
          <td class="fonte12_esq"><b>CPF <span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="5"><?php echo($param_cpf); ?></td>
        </tr>  

				<tr>
          <td class="titulo_azul_esq_20" colspan="9" bgcolor="#ebebeb" height="40px">:: Dados para Contato</td>
        </tr>

				<tr>
          <td class="fonte12_esq"><b>DDD <span style="color:red">*</span></b></td>
          <td class="fonte12_esq"><?php echo($param_ddd01); ?></td>
          <td class="fonte12_esq"><b>Telefone <span style="color:red">*</span></b></td>
          <td class="fonte12_esq"><?php echo($param_telefone01); ?></td>
          <td class="fonte12_esq"><b>DDD</b></td>
          <td class="fonte12_esq"><?php echo($param_ddd02); ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Telefone</b>&nbsp;&nbsp;&nbsp;<?php echo($param_telefone02); ?></td>
        </tr>

				<tr>
          <td class="fonte12_esq"><b>CEP <span style="color:red">*</span></b></td>
          <td class="fonte12_esq"><?php echo($param_cep); ?></td>
          <td class="fonte12_esq"><b>Estado <span style="color:red">*</span></b></td>
          <td class="fonte12_esq"><?php echo($param_uf); ?></td>
          <td class="fonte12_esq"><b>Cidade <span style="color:red">*</span></b></td>
          <td class="fonte12_esq"><?php echo($param_cidade); ?></td>
        </tr>

				<tr>
          <td class="fonte12_esq"><b>Logradouro</b></td>
          <td class="fonte12_esq" colspan="3"><?php echo($param_logradouro); ?></td>
          <td class="fonte12_esq"><b>Número</b></td>
          <td class="fonte12_esq"><?php echo($param_numero); ?>&nbsp;&nbsp;&nbsp;&nbsp;<b>Caixa Postal</b>&nbsp;&nbsp;&nbsp;<?php echo($param_caixa_postal); ?></td>
        </tr>
				<tr>
          <td class="fonte12_esq"><b>Bairro</b></td>
          <td class="fonte12_esq" colspan="3"><?php echo($param_bairro); ?></td>
          <td class="fonte12_esq"><b>Complemento</b></td>
          <td class="fonte12_esq"><?php echo($param_complemento); ?></td>
        </tr>
        
				<tr>
          <td class="fonte12_esq"><b>E-mail <span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="3"><?php echo($param_email); ?></td>
          <td class="fonte12_esq" colspan="2"></td>
        </tr>
        
				<tr>
          <td class="titulo_azul_esq_20" colspan="9" bgcolor="#ebebeb" height="40px">:: Dados Profissionais</td>
        </tr>
				<tr>
          <td class="fonte12_esq" colspan="9"><b>Perfil Profissional <span style="color:red">*</span></b><br><?php echo($param_perfil_profissional); ?></td>
        </tr>
				<tr>
          <td class="fonte12_esq" colspan="9"><b>Experiências Profissionais <span style="color:red">*</span></b><br><?php echo($param_experiencia_profissional); ?></td>
        </tr>
				<tr>
          <td class="fonte12_esq"><b>Grau de Escolaridade <span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="8"><?php echo($param_grau_escolaridade); ?></td>
        </tr>
				<tr>
          <td class="fonte12_esq" colspan="9"><b>Complemento Educacional <span style="color:red">*</span></b><br><?php echo($param_complemento_educacional); ?></td>
        </tr>
				<tr>
          <td class="fonte12_esq" colspan="9"><b>Referências Profissionais <span style="color:red">*</span></b><br><?php echo($param_referencia_profissional); ?></td>
        </tr>
				<tr>
          <td class="fonte12_esq"><b>Salário desejado <span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="8"><?php echo($param_salario); ?></td>
        </tr>
				<tr>
          <td class="titulo_azul_esq_20" colspan="9" bgcolor="#ebebeb" height="40px">:: Ocupação Desejada</td>
        </tr>
				<tr>
          <td class="fonte12_esq" colspan="9">
  <table width="100%" border="0" cellspacing="2" cellpadding="8">
<?php  
    try 
    {
	  	$sql5 = "select o.ocupacao
                 from pessoa_x_ocupacao po
                        inner join classificacao_ocupacao o
                          on (o.cod_ocupacao = po.cod_ocupacao)
                where po.cod_pessoa = :COD_PESSOA
                order by o.ocupacao";
	  	$parametros_sql5 = array(":COD_PESSOA"=>$param_pessoa);		
      $stmt5= $pdo->prepare($sql5);
      $stmt5->execute($parametros_sql5);
    }
    catch(PDOException $e)
    {
      $e->getMessage();
      echo "<span class='fonte_doze_negrito_erro'>[ Erro $e ]</span>";
      exit;
    };
    
    $vContador = 0;
	  $vCorLinha = "background-color:#edebeb;";
	  while ($result5 = $stmt5->fetch(PDO::FETCH_ASSOC))
	  {
      $vContador = ($vContador + 1);
      
	    if ($vCorLinha == "background-color:#FFFFFF;") 
      { 
        $vCorLinha = "background-color:#edebeb;";
      } 
      else 
      { 
        $vCorLinha = "background-color:#FFFFFF;"; 
      };    
?>
		<tr>
      <td class="fonte12_esq" style="<?PHP echo($vCorLinha); ?>"><?PHP echo($result5["ocupacao"]); ?></td>
		</tr> 
<?PHP	
	  };
?>
  </table>
          </td>
        </tr>
        
				<tr>
          <td class="titulo_azul_esq_20" colspan="9" bgcolor="#ebebeb" height="40px">:: Entrevista</td>
        </tr>
				<tr>
          <td class="fonte12_esq"><b>Data da Entrevista <span style="color:red">*</span></b></td>
          <td class="fonte12_esq"><input type="text" name="cp_data_entrevista" id="cp_data_entrevista" placeholder="DD/MM/AAAA" value="<?php echo($param_data_entrevista); ?>" size="10" maxlength="10" onkeypress="mascaraData( this, event )"></td>
          <td class="fonte12_esq"><b>Situação <span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="5">
            <select name='cp_aprovado' id='cp_aprovado'>
              <option value='P' <?php echo($vAprovadoPendente); ?>>Pendente</option>
              <option value='S' <?php echo($vAprovadoSim); ?>>Aprovado</option>
              <option value='N' <?php echo($vAprovadoNao); ?>>Reprovado</option>
            </select>
          </td>
        </tr>
				<tr>
          <td class="fonte12_esq" colspan="9">
            <b>Resumo da Entrevista <span style="color:red">*</span></b><br>
            <textarea id="cp_resumo_intrevista" name="cp_resumo_intrevista" rows="10" cols="120"><?php echo($param_resumo_intrevista); ?></textarea>
          </td>
        </tr>

				<tr>
          <td class="fonte14" colspan="9"><hr><br><span id="span_msg"><?php echo($vCamposObrigatorios); ?></span></td>
        </tr>
				<tr>
          <td class="fonte14_esq" colspan="9"><?echo($vUltimoAlterador);?><br><hr></td>
        </tr>
				<tr>
          <td class="fonte14" colspan="9"><center>
            <input type="submit" class="button_padrao" name="bt_alterar" value="&nbsp;&nbsp;Gravar Alteração&nbsp;&nbsp;">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="submit" class="button_padrao" name="bt_voltar" value="&nbsp;&nbsp;Voltar&nbsp;&nbsp;">
            <input type="hidden" id="param_vaga_candidato" name="param_vaga_candidato" value="<?PHP echo($param_vaga_candidato); ?>">
            <input type="hidden" id="param_cod_vaga" name="param_cod_vaga" value="<?PHP echo($param_cod_vaga); ?>">
          </td>
        </tr>
      </table>
    </form>
    <?php echo($vErroCodigo); ?>
  </body>
</html>