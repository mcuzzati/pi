<?php
function data_sistema($p_data)
{
	$v_retorno = "";
	if (!empty($p_data))
	{
    $p_data = preg_replace("/[^0-9]\//", "", $p_data);
		$vet_data = explode("/",$p_data);
		$v_retorno = $vet_data[2]."-".$vet_data[1]."-".$vet_data[0];
	}
	return $v_retorno;
}

function valor_banco($p_valor)
{
	$v_retorno = "";
	if (!empty($p_valor))
	{
		$p_valor = str_replace(".","",$p_valor);
		$p_valor = str_replace(",",".",$p_valor);
		$v_retorno = $p_valor;
	}
	return $v_retorno;
}

function so_numero($str) 
{
	return preg_replace("/[^0-9]/", "", $str);
}

?>