<?PHP	
  session_start();
  
  if (!isset($_SESSION['param_usuario']))
  { 
    session_destroy();
    echo("<script language='Javascript'>window.location = 'index.php'</script>");
  } 
	//if (!empty($_REQUEST['param_carta'])) 					{ $param_carta = trim($_REQUEST['param_carta']); } else { $param_carta = "NAO INFORMADO"; };
  
	require_once("seg_conexao.php");
  require_once("funcoes.php");
		
  try 
  {
    $pdo = connect();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  } catch(PDOException $e) {
    $e->getMessage();
    echo "<span class='fonte_doze_negrito_erro'>[ Erro $e ]</span>";
    exit;
  };
    
  $vErroCodigo = "";
    
  $param_nome_registro = "";
  $param_nome_social = "";
  $param_data_nasc = "";
  $param_cpf = "";
  $param_ddd01 = "";
  $param_telefone01 = "";
  $param_tipo01 = "";
  $param_ddd02 = "";
  $param_telefone02 = "";
  $param_tipo02 = "";
  $param_cep = "";
  $param_uf = "";
  $param_cidade = "";
  $param_logradouro = "";
  $param_numero = "";
  $param_bairro = "";
  $param_complemento = "";
  $param_caixa_postal = "";
  
  $param_perfil_profissional = "";
  $param_experiencia_profissional = "";
  $param_grau_escolaridade = "";
  $param_complemento_educacional = "";
  $param_referencia_profissional = "";
  $param_salario = "0";
  
  $param_email = "";
  $param_tipo_email = "";
  $param_senha = "";
  $param_conf_senha = "";
  
  $vCamposObrigatorios = "";
   
	if(isset($_REQUEST['bt_alterar']))
  {   
    if (!empty($_REQUEST['cp_nome_registro'])) 	{ $param_nome_registro = trim($_REQUEST['cp_nome_registro']); };
    if (!empty($_REQUEST['cp_nome_social'])) 		{ $param_nome_social = trim($_REQUEST['cp_nome_social']); };
    if (!empty($_REQUEST['cp_data_nasc'])) 			{ $param_data_nasc = trim($_REQUEST['cp_data_nasc']); $param_data_nasc_gv = data_sistema(trim($_REQUEST['cp_data_nasc']));};
    if (!empty($_REQUEST['cp_cpf'])) 					  { $param_cpf = so_numero(trim($_REQUEST['cp_cpf'])); };
    if (!empty($_REQUEST['cp_ddd01'])) 					{ $param_ddd01 = trim($_REQUEST['cp_ddd01']); };
    if (!empty($_REQUEST['cp_telefone01'])) 		{ $param_telefone01 = trim($_REQUEST['cp_telefone01']); };
    if (!empty($_REQUEST['cp_tipo01'])) 				{ $param_tipo01 = trim($_REQUEST['cp_tipo01']); };
    if (!empty($_REQUEST['cp_ddd02'])) 					{ $param_ddd02 = trim($_REQUEST['cp_ddd02']); };
    if (!empty($_REQUEST['cp_telefone02'])) 		{ $param_telefone02 = trim($_REQUEST['cp_telefone02']); };
    if (!empty($_REQUEST['cp_tipo02'])) 				{ $param_tipo02 = trim($_REQUEST['cp_tipo02']); } else { $param_tipo02 = null; };
    if (!empty($_REQUEST['cp_cep'])) 					  { $param_cep = so_numero(trim($_REQUEST['cp_cep'])); };
    if (!empty($_REQUEST['cp_uf'])) 					  { $param_uf = trim($_REQUEST['cp_uf']); };
    if (!empty($_REQUEST['cp_cidade'])) 				{ $param_cidade = trim($_REQUEST['cp_cidade']); };
    if (!empty($_REQUEST['cp_logradouro'])) 		{ $param_logradouro = trim($_REQUEST['cp_logradouro']); };
    if (!empty($_REQUEST['cp_numero'])) 				{ $param_numero = so_numero(trim($_REQUEST['cp_numero'])); };
    if (!empty($_REQUEST['cp_bairro'])) 				{ $param_bairro = trim($_REQUEST['cp_bairro']); };
    if (!empty($_REQUEST['cp_complemento'])) 		{ $param_complemento = trim($_REQUEST['cp_complemento']); };
    if (!empty($_REQUEST['cp_caixa_postal'])) 	{ $param_caixa_postal = so_numero(trim($_REQUEST['cp_caixa_postal'])); };
    
    if (!empty($_REQUEST['cp_perfil'])) 		      { $param_perfil_profissional = trim($_REQUEST['cp_perfil']); };
    if (!empty($_REQUEST['cp_experiencia'])) 	  	{ $param_experiencia_profissional = trim($_REQUEST['cp_experiencia']); };
    if (!empty($_REQUEST['cp_grau_escolar'])) 	  { $param_grau_escolaridade = trim($_REQUEST['cp_grau_escolar']); };
    if (!empty($_REQUEST['cp_comp_educacional'])) { $param_complemento_educacional = trim($_REQUEST['cp_comp_educacional']); };
    if (!empty($_REQUEST['cp_referencia'])) 		  { $param_referencia_profissional = trim($_REQUEST['cp_referencia']); };
    if (!empty($_REQUEST['cp_salario'])) 	        { $param_salario = trim($_REQUEST['cp_salario']); $param_salario_gv = valor_banco(trim($_REQUEST['cp_salario'])); };
    
    if (!empty($_REQUEST['cp_email'])) 					{ $param_email = trim($_REQUEST['cp_email']); };
    if (!empty($_REQUEST['cp_tipo_email'])) 		{ $param_tipo_email = trim($_REQUEST['cp_tipo_email']); };
    if (!empty($_REQUEST['cp_senha'])) 		      { $param_senha = trim($_REQUEST['cp_senha']); };
    if (!empty($_REQUEST['cp_conf_senha'])) 		{ $param_conf_senha = trim($_REQUEST['cp_conf_senha']); };
       
    $vSeparador = "";
    if (empty($param_nome_registro)) { $vCamposObrigatorios = "Nome de Registro"; $vSeparador = ", "; };
    if (empty($param_nome_social))   { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Nome de Registro"; $vSeparador = ", "; };
    
    if (empty($param_data_nasc))     { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Data de Nascimento"; $vSeparador = ", "; };
    if (empty($param_ddd01))         { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."DDD 01"; $vSeparador = ", "; };
    if (empty($param_telefone01))    { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Telefone 01"; $vSeparador = ", "; };
    
    if (empty($param_perfil_profissional))   { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Perfil Profissional"; $vSeparador = ", "; };
    if (empty($param_experiencia_profissional))   { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Experiência Profissional"; $vSeparador = ", "; };
    if (empty($param_grau_escolaridade))   { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Grau de Escolaridade"; $vSeparador = ", "; };
    if (empty($param_complemento_educacional))   { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Complemento Educacional"; $vSeparador = ", "; };
    if (empty($param_referencia_profissional))   { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Referencia Profissional"; $vSeparador = ", "; };
    if (empty($param_salario))   { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Salário Desejado"; $vSeparador = ", "; };
    
    if (empty($param_email))         { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."E-mail"; $vSeparador = ", "; };
    if (empty($param_senha))         { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Senha"; $vSeparador = ", "; };
    if (empty($param_conf_senha))    { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Confirmação de Senha"; $vSeparador = ", "; };
    
    if (!empty($vCamposObrigatorios))
    {
      $vCamposObrigatorios = $vCamposObrigatorios ." são campos obrigatório(s)."; 
      
      if (!empty($param_senha) and !empty($param_conf_senha))
      {
        if ($param_senha <> $param_conf_senha)
        {
          $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."<br>Senha e Confirmação de Senha não podem ser diferente.";
        }
      }
      $vCamposObrigatorios = "<font color='red' font-size: 14px>". $vCamposObrigatorios ."</font>"; 
    }
    else
    {
      if (!empty($param_senha) and !empty($param_conf_senha))
      {
        if ($param_senha <> $param_conf_senha)
        {
          $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."<font color='red' font-size: 14px>Senha e Confirmação de Senha não podem ser diferente.</font>";
        }
      }
    }
    
    if (empty($vCamposObrigatorios))
    {
      if (!empty($param_data_nasc))
      {
      	$vet_data = explode("/",$param_data_nasc);
      	$param_data_nasc_formatada = $vet_data[2]."-".$vet_data[1]."-".$vet_data[0];
      }
      if (!empty($param_cpf))
      {
      	$param_cpf_numeros = preg_replace("/[^0-9]/", "", $param_cpf);
      }
      if (!empty($param_cpf))
      {
      	$param_cep_numeros = preg_replace("/[^0-9]/", "", $param_cep);
      }
     
      try 
      { // CADASTRO DE PESSOA
        $sql = "update pessoa
                   set alteracao = now(),
                       id_usuario_alteracao = :ID_USER_EXECUCAO,
                       nome_oficial = :NOME_OFICIAL,
                       nome_social = :NOME_SOCIAL,
                       cpf = :CPF,
                       data_nascimento = :DATA_NASCIMENTO,
                       ddd_01 = :DDD_01,
                       telefone_01 = :TELEFONE_01,
                       ddd_02 = :DDD_02,
                       telefone_02 = :TELEFONE_02,
                       cep = :CEP,
                       cidade = :CIDADE,
                       uf = :UF,
                       logradouro = :LOGRADOURO,
                       numero = :NUMERO,
                       caixa_postal = :CAIXA_POSTAL,
                       bairro = :BAIRRO,
                       complemento = :COMPLEMENTO,
                       email = :EMAIL,
                       perfil_profissional = :PERFIL_PROFISSIONAL,
                       experiencia_profissional = :EXPERIENCIA_PROFISSIONAL,
                       cod_grau_escolaridade = :COD_GRAU_ESCOLARIDADE,
                       complemento_educacional = :COMPLEMENTO_EDUCACIONAL,
                       referencia = :REFERENCIA,
                       salario_desejado = :SALARIO_DESEJADO
                where cod_pessoa = :COD_PESSOA";
        $parametros_sql = array(":ID_USER_EXECUCAO"=>$_SESSION['param_cod_usuario'],
                                ":NOME_OFICIAL"=>$param_nome_registro,
                                ":NOME_SOCIAL"=>$param_nome_social,
                                ":CPF"=>$param_cpf,
                                ":DATA_NASCIMENTO"=>$param_data_nasc_gv,
                                ":DDD_01"=>$param_ddd01,
                                ":TELEFONE_01"=>$param_telefone01,
                                ":DDD_02"=>$param_ddd02,
                                ":TELEFONE_02"=>$param_telefone02,
                                ":CEP"=>$param_cep,
                                ":CIDADE"=>$param_cidade,
                                ":UF"=>$param_uf,
                                ":LOGRADOURO"=>$param_logradouro,
                                ":NUMERO"=>$param_numero,
                                ":CAIXA_POSTAL"=>$param_caixa_postal,
                                ":BAIRRO"=>$param_bairro,
                                ":COMPLEMENTO"=>$param_complemento,
                                ":EMAIL"=>$param_email,
                                ":PERFIL_PROFISSIONAL"=>$param_perfil_profissional,
                                ":EXPERIENCIA_PROFISSIONAL"=>$param_experiencia_profissional,
                                ":COD_GRAU_ESCOLARIDADE"=>$param_grau_escolaridade,
                                ":COMPLEMENTO_EDUCACIONAL"=>$param_complemento_educacional,
                                ":REFERENCIA"=>$param_referencia_profissional,
                                ":SALARIO_DESEJADO"=>$param_salario_gv,
                                ":COD_PESSOA"=>$_SESSION['param_cod_pessoa']);
        $stmt= $pdo->prepare($sql);
        $stmt->execute($parametros_sql);
        if( $stmt->rowCount() == 0 )
        {
          $vCamposObrigatorios = "<font color='red font-size: 14px'>Cadastro não foi concluído. Tente novamente.</font>";
        }
        else
        {
          $vCamposObrigatorios = "<font color='red font-size: 14px'>Cadastro atualizado com sucesso.</font>";
        }
      } 
      catch (PDOException $e) 
      {
        $e->getMessage();
        $vErroCodigo = $vErroCodigo ."Cadastro de usuário. Erro: $e <br>";
      };
    };
	}
  else
  {  
    if (!empty($_SESSION['param_cod_pessoa']))
    { // BUSCA DADOS DA BASE    
      try 
      {
        $sql = "select DATE_FORMAT(p.alteracao,'%d/%m/%Y %H:%i') as alteracao,
                       pa.nome_social as usuario_alteracao,
                       p.nome_oficial,
                       p.nome_social,
                       p.cpf,
                       DATE_FORMAT(p.data_nascimento,'%d/%m/%Y') as data_nascimento,
                       p.ddd_01,
                       p.telefone_01,
                       p.ddd_02,
                       p.telefone_02,
                       p.cep,
                       p.cidade,
                       p.uf,
                       p.logradouro,
                       p.numero,
                       p.caixa_postal,
                       p.bairro,
                       p.complemento,
                       p.email,
                       p.perfil_profissional,
                       p.experiencia_profissional,
                       p.cod_grau_escolaridade,
                       p.complemento_educacional,
                       p.referencia,
                       replace(p.salario_desejado,'.',',') as salario_desejado,
                       u.senha
                  from pessoa p
                        left join usuario u on (u.cod_usuario = p.id_usuario_alteracao)
                        left join pessoa pa on (pa.cod_pessoa = u.cod_pessoa)
                        where p.cod_pessoa = :COD_PESSOA";
        $parametros_sql = array(":COD_PESSOA"=>$_SESSION['param_cod_pessoa']);
        $stmt= $pdo->prepare($sql);
        $stmt->execute($parametros_sql);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!empty($result["nome_oficial"]))
        {        
          $param_nome_registro = $result["nome_oficial"];
          $param_nome_social = $result["nome_social"];
          $param_data_nasc = $result["data_nascimento"];
          $param_cpf = $result["cpf"];
          $param_ddd01 = $result["ddd_01"];
          $param_telefone01 = $result["telefone_01"];
          $param_ddd02 = $result["ddd_02"];
          $param_telefone02 = $result["telefone_02"];
          $param_cep = $result["cep"];
          $param_cidade = $result["cidade"];
          $param_uf = $result["uf"];
          $param_logradouro = $result["logradouro"];
          $param_numero = $result["numero"];
          $param_caixa_postal = $result["caixa_postal"];
          $param_bairro = $result["bairro"];
          $param_complemento = $result["complemento"];
          $param_email = $result["email"];
          $param_perfil_profissional = $result["perfil_profissional"];
          $param_experiencia_profissional = $result["experiencia_profissional"];
          $param_grau_escolaridade = $result["cod_grau_escolaridade"];
          $param_complemento_educacional = $result["complemento_educacional"];
          $param_referencia_profissional = $result["referencia"];
          $param_salario = $result["salario_desejado"];
          $param_senha = $result["senha"];
          $param_conf_senha = $result["senha"];
          
          $vUltimoAlterador = "Ultima alteração foi realizada em ". $result["alteracao"] ." por ". $result["usuario_alteracao"];
        };
        
      } catch(PDOException $e) {
        $e->getMessage();
        echo "<span class='fonte_doze_negrito_erro'>[ Erro $e ]</span>";
        exit;
      };
    }
  };
?>

<!DOCTYPE>
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Cadastro do Candidato</title>
    <script type="text/javascript" src="./js/jquery.js"></script>
    <script type="text/javascript" src="./js/jquery.maskedinput.js"/></script>
    <script>
    function Carrega_Formulario()
    {
      $("#div_cabecalho").load("cabecalho_ajax.php", {param_funcao: 'carregar'});
      Carrega_Ocupacoes();
    }
    
    function Carrega_Ocupacoes()
    {
      $("#div_ocupacoes").load("cadastro_candidato_ajax.php", {param_funcao: 'ocupacoes'});
    }
    
    function registra_ocupacao(ocupacao, operacao)
    { 
      $("#div_ocupacoes").load("cadastro_candidato_ajax.php", {param_funcao: 'registrar',
                                                               param_ocupacao: ocupacao,
                                                               param_operacao: operacao});
    }
    
    function ValidarUsuario()
    {
      $("#div_cabecalho").load("cabecalho_ajax.php", {param_funcao: 'validar_acesso', param_email: $("#var_email").val(), param_senha: $("#var_senha").val()});
    }
    
    function Logof()
    {
      $("#div_cabecalho").load("cabecalho_ajax.php", {param_funcao: 'logof'});
    }
    
    $(document).ready(function(){
      $("#cp_cpf").mask("999.999.999-99");
      $("#cp_cep").mask("99.999-999");
    });
    
    function mascaraData( campo, e )
    {
      var kC = (document.all) ? event.keyCode : e.keyCode;
      var data = campo.value;
      
      if( kC!=8 && kC!=46 )
      {
        if( data.length==2 )
        {
          campo.value = data += '/';
        }
        else if( data.length==5 )
        {
          campo.value = data += '/';
        }
        else
          campo.value = data;
      }
    }
    
    function validacaoEmail(field) 
    {
      usuario = field.value.substring(0, field.value.indexOf("@"));
      dominio = field.value.substring(field.value.indexOf("@")+ 1, field.value.length);

      if ((usuario.length >=1) &&
          (dominio.length >=3) &&
          (usuario.search("@")==-1) &&
          (dominio.search("@")==-1) &&
          (usuario.search(" ")==-1) &&
          (dominio.search(" ")==-1) &&
          (dominio.search(".")!=-1) &&
          (dominio.indexOf(".") >=1)&&
          (dominio.lastIndexOf(".") < dominio.length - 1)) {
        document.getElementById("span_msg").innerHTML="";
      }
      else
      {
        document.getElementById("span_msg").innerHTML="<font style='color: #FF0000;'>E-mail inválido</font>";
      }
    }
    
    function comparar_senha()
    {
      var vSenha = document.getElementById("cp_senha").value;
      var vConferirSenha = document.getElementById("cp_conf_senha").value;
      if (vSenha != vConferirSenha) 
      {
        document.getElementById("span_msg").innerHTML = "<font style='color: #FF0000;'>Senha e Confirmação de senha estão diferentes.</font>";
      }
      else
      {
        document.getElementById("span_msg").innerHTML = "";
      }
    }
    
    function BuscaCPF()
    {
      if (document.getElementById("cp_cpf").value != "") 
      {
        $.getJSON("cadastro_ajax.php", {param_funcao: "busca_cpf", param_cpf: document.getElementById("cp_cpf").value}, function(data){
          if (data[0] != 0)
          {
            document.getElementById("span_msg").innerHTML = "<font color='red'>CPF " + document.getElementById("cp_cpf").value + " já consta no cadastro.</font>";
          };
        });
      };
    }
    
    function BuscaEmail()
    {
      if (document.getElementById("cp_email").value != "") 
      {
        $.getJSON("cadastro_ajax.php", {param_funcao: "busca_email", param_email: document.getElementById("cp_email").value}, function(data){
          if (data[0] != 0)
          {
            document.getElementById("span_msg").innerHTML = "<font color='red'>E-mail " + document.getElementById("cp_email").value + " já consta no cadastro.</font>";
          };
        });
      };
    }
    
    function copia_nome()
    {
      if ($("#cp_nome_social").val() == "")
      {
        document.getElementById("cp_nome_social").value = $("#cp_nome_registro").val();
      }
    }
    
    function proximo_campo(vCampo)
    {
      if (vCampo == "cp_numero")
      {
        if ($("#cp_bairro").val() != "")
        {
          document.getElementById("cp_email").focus();
        }
      }
    }
    </script>
    <style type="text/css">
	  @import "css.css";
    </style>
  </head>
  <body onLoad="Carrega_Formulario()">
    <div id="div_cabecalho"></div>
    <table width="100%" border="0" align="center" background="./img/fundo_principal.png">
      <tr>
        <td height="135px">
          <table width="1000px" border="0" align="center">
            <tr>
              <td class="titulo_azul_20" height="50px" colspan="2"><br><br>Cadastro do Candidato<br><br></td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
    <center><br>
    <form id="FA" name="FA" method="post" action="cadastro_candidato.php">
      <table width="860px" border="0" cellspacing="6" cellpadding="2">
				<tr>
          <td class="titulo_azul_esq_20" colspan="9" bgcolor="#ebebeb" height="40px">:: Candidato</td>
        </tr>
				<tr>
          <td class="fonte12_esq"><b>Nome de Registro <span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="8"><input type="text" name="cp_nome_registro" id="cp_nome_registro" placeholder="Nome de Registro" value="<?php echo($param_nome_registro); ?>" size="90" onBlur="copia_nome();"></td>
        </tr>
				<tr>
          <td class="fonte12_esq"><b>Nome Social <span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="8"><input type="text" name="cp_nome_social" id="cp_nome_social" placeholder="Nome Social" value="<?php echo($param_nome_social); ?>" size="90"></td>
        </tr>
        
				<tr>
          <td class="fonte12_esq"><b>Nascimento <span style="color:red">*</span></b></td>
          <td class="fonte12_esq"><input type="text" name="cp_data_nasc" id="cp_data_nasc" placeholder="DD/MM/AAAA" value="<?php echo($param_data_nasc); ?>" size="10" maxlength="10" onkeypress="mascaraData( this, event )"></td>
          <td class="fonte12_esq"><b>CPF <span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="5"><input type="text" name="cp_cpf" id="cp_cpf" placeholder="CPF" value="<?php echo($param_cpf); ?>" size="11" maxlength="10" onBlur="BuscaCPF()"></td>
        </tr>  

				<tr>
          <td class="titulo_azul_esq_20" colspan="9" bgcolor="#ebebeb" height="40px">:: Dados para Contato</td>
        </tr>

				<tr>
          <td class="fonte12_esq"><b>DDD <span style="color:red">*</span></b></td>
          <td class="fonte12_esq"><input type="text" name="cp_ddd01" id="cp_ddd01" placeholder="DDD" value="<?php echo($param_ddd01); ?>" size="2" maxlength="2"></td>
          <td class="fonte12_esq"><b>Telefone <span style="color:red">*</span></b></td>
          <td class="fonte12_esq"><input type="text" name="cp_telefone01" id="cp_telefone01" placeholder="Telefone" value="<?php echo($param_telefone01); ?>" size="11" maxlength="9"></td>
          <td class="fonte12_esq"><b>DDD</b></td>
          <td class="fonte12_esq">
            <input type="text" name="cp_ddd02" id="cp_ddd02" placeholder="DDD" value="<?php echo($param_ddd02); ?>" size="2" maxlength="2">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Telefone</b>&nbsp;&nbsp;&nbsp;
            <input type="text" name="cp_telefone02" id="cp_telefone02" placeholder="Telefone" value="<?php echo($param_telefone02); ?>" size="11" maxlength="9">
          </td>
        </tr>

				<tr>
          <td class="fonte12_esq"><b>CEP <span style="color:red">*</span></b></td>
          <td class="fonte12_esq"><input type="text" name="cp_cep" id="cp_cep" placeholder="CEP" value="<?php echo($param_cep); ?>" size="8"></td>
          <td class="fonte12_esq"><b>Estado <span style="color:red">*</span></b></td>
          <td class="fonte12_esq">
            <select name='cp_uf' id='cp_uf'>
              <option value='AC' <?php if ('AC' == $param_uf) { ECHO("SELECTED"); }; ?>>Acre</option>
              <option value='AL' <?php if ('AL' == $param_uf) { ECHO("SELECTED"); }; ?>>Alagoas</option>
              <option value='AP' <?php if ('AP' == $param_uf) { ECHO("SELECTED"); }; ?>>Amapa</option>
              <option value='AM' <?php if ('AM' == $param_uf) { ECHO("SELECTED"); }; ?>>Amazonas</option>
              <option value='BA' <?php if ('BA' == $param_uf) { ECHO("SELECTED"); }; ?>>Bahia</option>
              <option value='CE' <?php if ('CE' == $param_uf) { ECHO("SELECTED"); }; ?>>CEARA</option>
              <option value='DF' <?php if ('DF' == $param_uf) { ECHO("SELECTED"); }; ?>>Distrito Federal</option>
              <option value='ES' <?php if ('ES' == $param_uf) { ECHO("SELECTED"); }; ?>>Espirito Santo</option>
              <option value='GO' <?php if ('GO' == $param_uf) { ECHO("SELECTED"); }; ?>>Goias</option>
              <option value='MA' <?php if ('MA' == $param_uf) { ECHO("SELECTED"); }; ?>>Maranhao</option>
              <option value='MT' <?php if ('MT' == $param_uf) { ECHO("SELECTED"); }; ?>>Mato Grosso</option>
              <option value='MS' <?php if ('MS' == $param_uf) { ECHO("SELECTED"); }; ?>>Mato Grosso do Sul</option>
              <option value='MG' <?php if ('MG' == $param_uf) { ECHO("SELECTED"); }; ?>>Minas Gerais</option>
              <option value='PA' <?php if ('PA' == $param_uf) { ECHO("SELECTED"); }; ?>>Para</option>
              <option value='PB' <?php if ('PB' == $param_uf) { ECHO("SELECTED"); }; ?>>Paraiba</option>
              <option value='PR' <?php if ('PR' == $param_uf) { ECHO("SELECTED"); }; ?>>Parana</option>
              <option value='PE' <?php if ('PE' == $param_uf) { ECHO("SELECTED"); }; ?>>Pernambuco</option>
              <option value='PI' <?php if ('PI' == $param_uf) { ECHO("SELECTED"); }; ?>>Piaui</option>
              <option value='RJ' <?php if ('RJ' == $param_uf) { ECHO("SELECTED"); }; ?>>Rio de Janeiro</option>
              <option value='RN' <?php if ('RN' == $param_uf) { ECHO("SELECTED"); }; ?>>Rio Grande do Norte</option>
              <option value='RS' <?php if ('RS' == $param_uf) { ECHO("SELECTED"); }; ?>>Rio Grande do Sul</option>
              <option value='RO' <?php if ('RO' == $param_uf) { ECHO("SELECTED"); }; ?>>Rondonia</option>
              <option value='RR' <?php if ('RR' == $param_uf) { ECHO("SELECTED"); }; ?>>Roraima</option>
              <option value='SC' <?php if ('SC' == $param_uf) { ECHO("SELECTED"); }; ?>>Santa Catarina</option>
              <option value='SP' <?php if ('SP' == $param_uf) { ECHO("SELECTED"); }; ?>>São Paulo</option>
              <option value='SE' <?php if ('SE' == $param_uf) { ECHO("SELECTED"); }; ?>>Sergipe</option>
              <option value='TO' <?php if ('TO' == $param_uf) { ECHO("SELECTED"); }; ?>>Tocantins</option>
            </select>
          </td>
          <td class="fonte12_esq"><b>Cidade <span style="color:red">*</span></b></td>
          <td class="fonte12_esq"><input type="text" name="cp_cidade" id="cp_cidade" placeholder="Cidade" value="<?php echo($param_cidade); ?>" size="30"></td>
        </tr>

				<tr>
          <td class="fonte12_esq"><b>Logradouro</b></td>
          <td class="fonte12_esq" colspan="3"><input type="text" name="cp_logradouro" id="cp_logradouro" placeholder="Logradouro" value="<?php echo($param_logradouro); ?>" size="40"></td>
          <td class="fonte12_esq"><b>Número</b></td>
          <td class="fonte12_esq">
            <input type="text" name="cp_numero" id="cp_numero" placeholder="Numero" value="<?php echo($param_numero); ?>" size="5" onBlur="proximo_campo('cp_numero');">
            &nbsp;&nbsp;&nbsp;&nbsp;<b>Caixa Postal</b>&nbsp;&nbsp;&nbsp;
            <input type="text" name="cp_caixa_postal" id="cp_caixa_postal" placeholder="Numero" value="<?php echo($param_caixa_postal); ?>" size="5">
          </td>
        </tr>
				<tr>
          <td class="fonte12_esq"><b>Bairro</b></td>
          <td class="fonte12_esq" colspan="3"><input type="text" name="cp_bairro" id="cp_bairro" placeholder="Bairro" value="<?php echo($param_bairro); ?>" size="40"></td>
          <td class="fonte12_esq"><b>Complemento</b></td>
          <td class="fonte12_esq"><input type="text" name="cp_complemento" id="cp_complemento" placeholder="Complemento" value="<?php echo($param_complemento); ?>" size="30"></td>
        </tr>
        
				<tr>
          <td class="fonte12_esq"><b>E-mail <span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="3"><input type="text" name="cp_email" id="cp_email" placeholder="E-mail" value="<?php echo($param_email); ?>" size="40" onBlur="BuscaEmail()"></td>
          <td class="fonte12_esq"><b>Conf. de E-mail <span style="color:red">*</span></b></td>
          <td class="fonte12_esq"><input type="text" name="cp_conf_email" id="cp_conf_email" placeholder="Confirmação de E-mail" value="<?php echo($param_email); ?>" size="30" onBlur="ConfEmail()"></td>
        </tr>
        
				<tr>
          <td class="titulo_azul_esq_20" colspan="9" bgcolor="#ebebeb" height="40px">:: Dados Profissionais</td>
        </tr>
				<tr>
          <td class="fonte12_esq" colspan="9">
            <b>Perfil Profissional <span style="color:red">*</span></b> (Digite uma breve descrição do seu perfil profissional)<br>
            <textarea id="cp_perfil" name="cp_perfil" rows="10" cols="120"><?php echo($param_perfil_profissional); ?></textarea>
          </td>
        </tr>
				<tr>
          <td class="fonte12_esq" colspan="9">
            <b>Experiências Profissionais <span style="color:red">*</span></b> (Informe suas experiências profissionais)<br>
            <textarea id="cp_experiencia" name="cp_experiencia" rows="10" cols="120"><?php echo($param_experiencia_profissional); ?></textarea>
          </td>
        </tr>
				<tr>
          <td class="fonte12_esq"><b>Grau de Escolaridade <span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="8">
            <select name='cp_grau_escolar' id='cp_grau_escolar'>
<?php 
     try 
     {
      $sql3 = "select cod_grau_escolaridade, grau_escolaridade from grau_escolaridade order by cod_grau_escolaridade";
      $stmt3= $pdo->prepare($sql3);
      $stmt3->execute();
    }
    catch(PDOException $e)
    {
      $e->getMessage();
      $vErroCodigo = $vErroCodigo ."Busca tipo de telefone 01. Erro: $e <br>";
      exit;
    };
    while ($result3 = $stmt3->fetch(PDO::FETCH_ASSOC)) 
    {
      $vSelecionado = "";
      if ($result3["cod_grau_escolaridade"] == $param_grau_escolaridade) { $vSelecionado = "SELECTED"; };
      echo("<option value='". $result3["cod_grau_escolaridade"] ."' ". $vSelecionado .">". $result3["grau_escolaridade"] ."</option>");
    }
?>
              
            </select>
          </td>
        </tr>
				<tr>
          <td class="fonte12_esq" colspan="9">
            <b>Complemento Educacional <span style="color:red">*</span></b> (Informe onde estudou, quando frequentou, qual curso frequentou, se esta cursando ou concluiu ...)<br>
            <textarea id="cp_comp_educacional" name="cp_comp_educacional" rows="10" cols="120"><?php echo($param_complemento_educacional); ?></textarea>
          </td>
        </tr>
				<tr>
          <td class="fonte12_esq" colspan="9">
            <b>Referências Profissionais <span style="color:red">*</span></b> (Informe quem pode dar referência de seus trabalhos ...)<br>
            <textarea id="cp_referencia" name="cp_referencia" rows="10" cols="120"><?php echo($param_referencia_profissional); ?></textarea>
          </td>
        </tr>
				<tr>
          <td class="fonte12_esq" colspan="9">
            <b>Ocupações desejadas <span style="color:red">*</span></b> (Selecione uma ou multiplas ocupações que pode exercer)<br>
            <div id="div_ocupacoes" style="width: 100%; height: 316px; overflow:auto;"></div>
          </td>
        </tr>
				<tr>
          <td class="fonte12_esq"><b>Salário desejado <span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="8"><input type="text" name="cp_salario" id="cp_salario" placeholder="Digite o valor" value="<?php echo($param_salario); ?>" size="15"></td>
        </tr>
        
				<tr>
          <td class="titulo_azul_esq_20" colspan="9" bgcolor="#ebebeb" height="40px">:: Senha de Acesso</td>
        </tr>
        
				<tr>
          <td class="fonte12_esq"><b>Senha <span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="2"><input type="password" name="cp_senha" id="cp_senha" value="<?php echo($param_senha); ?>" size="15" minlength="6" onchange="comparar_senha()"></td>
          <td class="fonte12_esq"><b>Confirmação de Senha <span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="2"><input type="password" name="cp_conf_senha" id="cp_conf_senha" value="<?php echo($param_conf_senha); ?>" size="15" minlength="6" onchange="comparar_senha()"><span id="span_msg_senha"></span></td>
        </tr>
				<tr>
          <td class="fonte14" colspan="9"><span id="span_msg"><?php echo($vCamposObrigatorios); ?></span></td>
        </tr>
				<tr>
          <td class="fonte14_esq" colspan="9"><?echo($vUltimoAlterador);?><br><hr></td>
        </tr>
				<tr>
          <td class="fonte14" colspan="9"><center><input type="submit" class="button_padrao" name="bt_alterar" value="&nbsp;&nbsp;Gravar Alteração&nbsp;&nbsp;"></td>
        </tr>
      </table>
    </form>
    <?php echo($vErroCodigo); ?>
  </body>
</html>