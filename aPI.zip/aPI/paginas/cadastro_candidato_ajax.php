<?php	
  session_start();
  $vResultado = "";
	if ($_REQUEST["param_funcao"] == "logof") 
  { 
    session_destroy();
    echo("<script language='Javascript'>window.location = 'index.php'</script>");
  };
  
  require_once("seg_conexao.php");
  
  if ($_REQUEST["param_funcao"] == "registrar") 
  {  
    if (isset($_REQUEST["param_ocupacao"])) { $param_ocupacao = $_REQUEST["param_ocupacao"]; } else { $param_ocupacao = 0; };  
    if (isset($_REQUEST["param_operacao"])) { $param_operacao = $_REQUEST["param_operacao"]; } else { $param_operacao = "X"; }; 

    try 
    {
      $pdo = connect();
      $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch(PDOException $e) {
      $e->getMessage();
      echo "<span class='fonte_doze_negrito_erro'>[ Erro $e ]</span>";
      exit;
    };

    if ($param_operacao == "S")
    {
      try 
      { 
        $sql = "insert into pessoa_x_ocupacao
                 (alteracao, id_usuario_alteracao, cod_pessoa, cod_ocupacao)
                 values (now(), :ID_USER, :COD_PESSOA, :COD_OCUPACAO)";
        $parametros_sql = array(":ID_USER"=>$_SESSION['param_cod_usuario'],
                                ":COD_PESSOA"=>$_SESSION['param_cod_pessoa'],
                                ":COD_OCUPACAO"=>$param_ocupacao);
        $stmt= $pdo->prepare($sql);
        $stmt->execute($parametros_sql);
        if( $stmt->rowCount() == 0 ) 
        { 
          $vQtdErros = 1;
          $vErro = 'Registro não executado. Tente novamente.';
        }
        else
        { 
          $vQtdErros = 0;
          $vErro = 'Atualizado com sucesso.';
        };
      } 
      catch (PDOException $e) 
      {
        $e->getMessage();
        $vErroCodigo = $vErroCodigo ."Regisro de ocupação. Erro: $e <br>";
      };
    }
    elseif ($param_operacao == "N")
    {
      try 
      { 
        $sql = "delete from pessoa_x_ocupacao
                 where cod_ocupacao = :COD_OCUPACAO
                   and cod_pessoa = :COD_PESSOA";
        $parametros_sql = array(":COD_PESSOA"=>$_SESSION['param_cod_pessoa'],
                                ":COD_OCUPACAO"=>$param_ocupacao);

        $stmt= $pdo->prepare($sql);
        $stmt->execute($parametros_sql);
        if( $stmt->rowCount() == 0 ) 
        { 
          $vQtdErros = 1;
          $vErro = 'Registro não executado. Tente novamente.';
        }
        else
        { 
          $vQtdErros = 0;
          $vErro = 'Atualizado com sucesso.';
        };
      } 
      catch (PDOException $e) 
      {
        $e->getMessage();
        $vErroCodigo = $vErroCodigo ."Exclusão de ocupação. Erro: $e <br>";
      };
    };
  }
  
	if ($_REQUEST["param_funcao"] == "ocupacoes" OR $_REQUEST["param_funcao"] == "registrar") 
  {  
    try 
    {
      $pdo = connect();
      $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch(PDOException $e) {
      $e->getMessage();
      echo "<span class='fonte_doze_negrito_erro'>[ Erro $e ]</span>";
      exit;
    };
     
?>
  <table width="100%" border="0" cellspacing="2" cellpadding="8" id="table_lista">
<?php  
    try 
    {
	  	$sql = "select o.cod_ocupacao, o.ocupacao, coalesce(po.cod_pessoa_ocupacao,0) as cod_pessoa_ocupacao
                from classificacao_ocupacao o
                      left join pessoa_x_ocupacao po
                       on (po.cod_pessoa = :COD_PESSOA
                           and po.cod_ocupacao = o.cod_ocupacao)
               order by 3 desc, 1";
	  	$parametros_sql = array(":COD_PESSOA"=>$_SESSION['param_cod_pessoa']);		
      $stmt= $pdo->prepare($sql);
      $stmt->execute($parametros_sql);
    }
    catch(PDOException $e)
    {
      $e->getMessage();
      echo "<span class='fonte_doze_negrito_erro'>[ Erro $e ]</span>";
      exit;
    };
    
    $vContador = 0;
	  $vCorLinha = "background-color:#FFFFFF;";
	  while ($result = $stmt->fetch(PDO::FETCH_ASSOC))
	  {
      $vContador = ($vContador + 1);
      if ($vContador == 1) 
      {
?>
		<tr>
			<td class="fonte12"><b>Selecionado</b></td>
      <td class="fonte12"><b>Ocupação</b></td>
		</tr> 
<?php
      }
      
	    if ($vCorLinha == "background-color:#FFFFFF;") 
      { 
        $vCorLinha = "background-color:#edebeb;";
      } 
      else 
      { 
        $vCorLinha = "background-color:#FFFFFF;"; 
      };    
?>
		<tr>
			<td class="fonte12" style="<?PHP echo($vCorLinha); ?>" width="100px" id="td<?PHP echo($result["cod_ocupacao"]); ?>">
<?PHP if ($result["cod_pessoa_ocupacao"] == 0) { ?>
        <input type="button" class="button_nao" name="bt_canc_registro" id="bt_canc_registro" value="&nbsp;&nbsp;NÃO&nbsp;&nbsp;" onClick="registra_ocupacao(<?php echo($result['cod_ocupacao']); ?>,'S')">
<?PHP }
      else 
      {
?>
        <input type="button" class="button_sim" name="bt_registrar" id="bt_registrar" value="&nbsp;&nbsp;SIM&nbsp;&nbsp;" onClick="registra_ocupacao(<?php echo($result['cod_ocupacao']); ?>,'N')">
<?PHP
      }; 
?>
      </td>
      <td class="fonte12_esq" style="<?PHP echo($vCorLinha); ?>"><?PHP echo($result["ocupacao"]); ?></td>
		</tr> 
<?PHP	
	  };
?>
  </table>
<?PHP	
  
  };  

?>