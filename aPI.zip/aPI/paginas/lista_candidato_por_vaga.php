<?php	
  session_start();
  if (!isset($_SESSION['param_usuario']) or $_SESSION['param_tipo_usuario'] <> "CL")
  { 
    session_destroy();
    echo("<script language='Javascript'>window.location = 'index.php'</script>");
  }

  if (!empty($_REQUEST['param_cod_vaga'])) { $param_cod_vaga = trim($_REQUEST['param_cod_vaga']); } else { $param_cod_vaga = "0"; };

  require_once("seg_conexao.php");
    
  try 
	{  
	  $pdo = connect();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	}
	catch(PDOException $e)
	{
		$e->getMessage();
		echo "<span class='fonte_doze_negrito_erro'>Conectando com Banco de Dados. [ Erro $e ]</span>";
		exit;
	};
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Lista de Candidatos por Vaga</title>
<style type="text/css">
  @import "css.css";
  @import "./font-awesome/css/all.min.css"
</style>
<script type="text/javascript" src="./js/jquery.maskedinput.js" ></script>
<script type="text/javascript" src="./js/jquery.js"></script>
<script type="text/javascript" src="./js/jquery.form.js"></script>
<script type="text/javascript" src="./js/jquery.selects.js"></script>
<script language="javascript">
  function Carrega_Formulario()
  {
    $("#div_cabecalho").load("cabecalho_ajax.php", {param_funcao: 'carregar'});
  }

  function Voltar()
  {
    window.location = 'lista_vagas_emprego.php';
  }
</script>
</head>
<body onLoad="Carrega_Formulario()">
  <center>
  <div id="div_cabecalho"></div> 
  <table width="100%" border="0" align="center" background="./img/fundo_principal.png">
    <tr>
      <td height="135px">
        <table width="1000px" border="0" align="center">
          <tr>
            <td class="titulo_azul_20" height="50px" colspan="2"><br><br><br><br></td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
  <br>
  <table width="1000px" border="0" cellspacing="2" cellpadding="2">
    <tr height="40px">
      <td bgcolor="#a6bce8" class="titulo_padrao arredondamento_superior" colspan="5">
        Lista de Candidatos por Vaga
      </td>
    </tr>
    <tr height="20px">
      <td bgcolor="#a6bce8" class="titulo_padrao"></td>
      <td bgcolor="#a6bce8" class="titulo_padrao">Candidato</td>
      <td bgcolor="#a6bce8" class="titulo_padrao">Situação</td>
      <td bgcolor="#a6bce8" class="titulo_padrao">Entrevista</td>
      <td bgcolor="#a6bce8" class="titulo_padrao">Alteração</td>
    </tr>
<?php  
  try 
  {                 
		$sql = "select v.cod_vaga_candidato,
                   cd.nome_social as candidato,
                   DATE_FORMAT(v.entrevistar,'%d/%m/%Y') AS entrevistar,
                   (CASE
                     WHEN v.aprovado = 'A' THEN 'Aprovado'
                     WHEN v.aprovado = 'N' THEN 'Reprovado'
                     ELSE 'Pendente'
                    END) as situacao,
                   pa.nome_social as usuario_alteracao,
                   DATE_FORMAT(v.alteracao,'%d/%m/%Y %H:%i') as alteracao
              from vaga_emprego_x_elegivel v
                    inner join usuario ua on (ua.cod_usuario = v.id_usuario_alteracao)
                    inner join pessoa pa on (pa.cod_pessoa = ua.cod_pessoa)
                    inner join pessoa cd on (cd.cod_pessoa = v.cod_pessoa_candidato)
             where v.cod_vaga_emprego = :COD_VAGA_EMPREGO";
    $parametros_sql = array(":COD_VAGA_EMPREGO"=>$param_cod_vaga);
    $stmt= $pdo->prepare($sql);
    $stmt->execute($parametros_sql);
  }
  catch(PDOException $e)
  {
    $e->getMessage();
    echo "<span class='fonte_doze_negrito_erro'>[ Erro $e ]</span>";
    exit;
  };
  
  $vContador = 0; $vCorLinha == "#bfc8db";
  while ($result = $stmt->fetch(PDO::FETCH_ASSOC)) 
  {
    $vContador = ($vContador + 1);
    if ($vCorLinha == "#bfc8db") { $vCorLinha = "#ffffff"; } else { $vCorLinha = "#bfc8db"; };
?>
    <tr height="40px">
      <td bgcolor="<?php echo($vCorLinha); ?>" class="fonte14" width="40px">
        <a href="entrevista.php?op=ED&param_vaga_candidato=<?php echo($result["cod_vaga_candidato"]); ?>&param_cod_vaga=<?php echo($param_cod_vaga); ?>">
          <span style="color: #9c5709; font-size: 25px;"><i class="icon_fa fas fa-edit" title="Editar Registro"></i></span></a>
      </td>
      <td bgcolor="<?php echo($vCorLinha); ?>" class="fonte14_esq">&nbsp;&nbsp;&nbsp;<?php echo($result["candidato"]); ?></td>
      <td bgcolor="<?php echo($vCorLinha); ?>" class="fonte14"><?php echo($result["situacao"]); ?></td>
      <td bgcolor="<?php echo($vCorLinha); ?>" class="fonte14"><?php echo($result["entrevistar"]); ?></td>
      <td bgcolor="<?php echo($vCorLinha); ?>" class="fonte12_esq" width="220px">&nbsp;&nbsp;&nbsp;Alterado em: <?php echo($result["alteracao"] ."<br>&nbsp;&nbsp;&nbsp;Por: ". $result["usuario_alteracao"]); ?></td>
    </tr>
<?php
  };
  
  if ($vContador == 0)
  {
?>
    <tr height="40px">
      <td bgcolor="<?php echo($vCorLinha); ?>" class="fonte14" colspan="5">Não há candidatos</td>
    </tr>
<?php
  }
?>
    <tr height="15px">
      <td bgcolor="#a6bce8" class="titulo_padrao arredondamento_inferior" colspan="5">
        <button class="button_padrao" onclick="Voltar()">&nbsp;&nbsp;Voltar&nbsp;&nbsp;</button>
      </td>
    </tr>
  </table>
</body>
</html>
