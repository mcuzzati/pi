<?PHP	
  session_start();
	if (!empty($_REQUEST['param_carta'])) 					{ $param_carta = trim($_REQUEST['param_carta']); } else { $param_carta = "NAO INFORMADO"; };
  
	require_once("seg_conexao.php");
		
  try 
  {
    $pdo = connect();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  } catch(PDOException $e) {
    $e->getMessage();
    echo "<span class='fonte_doze_negrito_erro'>[ Erro $e ]</span>";
    exit;
  };
    
  $vErroCodigo = "";
    
  $param_nome_registro = "";
  $param_nome_social = "";
  $param_data_nasc = "";
  $param_cpf = "";
  $param_ddd01 = "";
  $param_telefone01 = "";
  $param_tipo01 = "";
  $param_ddd02 = "";
  $param_telefone02 = "";
  $param_tipo02 = "";
  $param_cep = "";
  $param_uf = "";
  $param_cidade = "";
  $param_logradouro = "";
  $param_numero = "";
  $param_bairro = "";
  $param_complemento = "";
  $param_caixa_postal = "";
  $param_email = "";
  $param_tipo_email = "";
  $param_senha = "";
  $param_conf_senha = "";
  
  $vCamposObrigatorios = "";
  
	if(isset($_REQUEST['bt_gravar']))
  {   
    if (!empty($_REQUEST['cp_nome_registro'])) 	{ $param_nome_registro = trim($_REQUEST['cp_nome_registro']); };
    if (!empty($_REQUEST['cp_nome_social'])) 		{ $param_nome_social = trim($_REQUEST['cp_nome_social']); };
    if (!empty($_REQUEST['cp_data_nasc'])) 			{ $param_data_nasc = trim($_REQUEST['cp_data_nasc']); };
    if (!empty($_REQUEST['cp_cpf'])) 					  { $param_cpf = trim($_REQUEST['cp_cpf']); };
    if (!empty($_REQUEST['cp_ddd01'])) 					{ $param_ddd01 = trim($_REQUEST['cp_ddd01']); };
    if (!empty($_REQUEST['cp_telefone01'])) 		{ $param_telefone01 = trim($_REQUEST['cp_telefone01']); };
    if (!empty($_REQUEST['cp_tipo01'])) 				{ $param_tipo01 = trim($_REQUEST['cp_tipo01']); };
    if (!empty($_REQUEST['cp_ddd02'])) 					{ $param_ddd02 = trim($_REQUEST['cp_ddd02']); };
    if (!empty($_REQUEST['cp_telefone02'])) 		{ $param_telefone02 = trim($_REQUEST['cp_telefone02']); };
    if (!empty($_REQUEST['cp_tipo02'])) 				{ $param_tipo02 = trim($_REQUEST['cp_tipo02']); } else { $param_tipo02 = null; };
    if (!empty($_REQUEST['cp_cep'])) 					  { $param_cep = trim($_REQUEST['cp_cep']); };
    if (!empty($_REQUEST['cp_uf'])) 					  { $param_uf = trim($_REQUEST['cp_uf']); };
    if (!empty($_REQUEST['cp_cidade'])) 				{ $param_cidade = trim($_REQUEST['cp_cidade']); };
    if (!empty($_REQUEST['cp_logradouro'])) 		{ $param_logradouro = trim($_REQUEST['cp_logradouro']); };
    if (!empty($_REQUEST['cp_numero'])) 				{ $param_numero = trim($_REQUEST['cp_numero']); };
    if (!empty($_REQUEST['cp_bairro'])) 				{ $param_bairro = trim($_REQUEST['cp_bairro']); };
    if (!empty($_REQUEST['cp_complemento'])) 		{ $param_complemento = trim($_REQUEST['cp_complemento']); };
    if (!empty($_REQUEST['cp_caixa_postal'])) 	{ $param_caixa_postal = trim($_REQUEST['cp_caixa_postal']); };
    if (!empty($_REQUEST['cp_email'])) 					{ $param_email = trim($_REQUEST['cp_email']); };
    if (!empty($_REQUEST['cp_tipo_email'])) 		{ $param_tipo_email = trim($_REQUEST['cp_tipo_email']); };
    if (!empty($_REQUEST['cp_senha'])) 		      { $param_senha = trim($_REQUEST['cp_senha']); };
    if (!empty($_REQUEST['cp_conf_senha'])) 		{ $param_conf_senha = trim($_REQUEST['cp_conf_senha']); };
       
    $vSeparador = "";
    if (empty($param_nome_registro)) { $vCamposObrigatorios = "Nome de Registro"; $vSeparador = ", "; };
    if (empty($param_nome_social))   { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Nome de Registro"; $vSeparador = ", "; };
    if (empty($param_data_nasc))   { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Data de Nascimento"; $vSeparador = ", "; };
    if (empty($param_cpf))   { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."CPF"; $vSeparador = ", "; };
    if (empty($param_ddd01))   { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."DDD 01"; $vSeparador = ", "; };
    if (empty($param_telefone01))   { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Telefone 01"; $vSeparador = ", "; };
    if (empty($param_tipo01))   { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Tipo de Telefone 01"; $vSeparador = ", "; };
    //if (empty($param_ddd02))   { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."DDD 02"; $vSeparador = ", "; };
    //if (empty($param_telefone02))   { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Telefone 02"; $vSeparador = ", "; };
    //if (empty($param_tipo02))   { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Tipo de Telefone 02"; $vSeparador = ", "; };
    if (empty($param_cep))   { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."CEP"; $vSeparador = ", "; };
    if (empty($param_uf))   { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."UF"; $vSeparador = ", "; };
    if (empty($param_cidade))   { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Cidade"; $vSeparador = ", "; };
    if (empty($param_logradouro))   { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Logradouro"; $vSeparador = ", "; };
    if (empty($param_numero))   { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Numero do Endereço"; $vSeparador = ", "; };
    if (empty($param_bairro))   { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Bairro"; $vSeparador = ", "; };
    if (empty($param_email))   { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."E-mail"; $vSeparador = ", "; };
    if (empty($param_tipo_email))   { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Tipo de E-mail"; $vSeparador = ", "; };
    if (empty($param_senha))   { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Senha"; $vSeparador = ", "; };
    if (empty($param_conf_senha))   { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Confirmação de Senha"; $vSeparador = ", "; };
    
    if (!empty($vCamposObrigatorios))
    {
      $vCamposObrigatorios = $vCamposObrigatorios ." são campos obrigatório(s)."; 
      
      if (!empty($param_senha) and !empty($param_conf_senha))
      {
        if ($param_senha <> $param_conf_senha)
        {
          $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."<br>Senha e Confirmação de Senha não podem ser diferente.";
        }
      }
      $vCamposObrigatorios = "<font color='red' font-size: 14px>". $vCamposObrigatorios ."</font>"; 
    }
    else
    {
      if (!empty($param_senha) and !empty($param_conf_senha))
      {
        if ($param_senha <> $param_conf_senha)
        {
          $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."<font color='red' font-size: 14px>Senha e Confirmação de Senha não podem ser diferente.</font>";
        }
      }
    }
    
    if (empty($vCamposObrigatorios))
    {
     
      if (!empty($param_data_nasc))
      {
      	$vet_data = explode("/",$param_data_nasc);
      	$param_data_nasc_formatada = $vet_data[2]."-".$vet_data[1]."-".$vet_data[0];
      }
      if (!empty($param_cpf))
      {
      	$param_cpf_numeros = preg_replace("/[^0-9]/", "", $param_cpf);
      }
      if (!empty($param_cpf))
      {
      	$param_cep_numeros = preg_replace("/[^0-9]/", "", $param_cep);
      }
     
      try 
      {
        $sql = "call proc_municipe('CADASTRAR',
                                   :HASH_PREFEITURA,
                                   :NOME_OFICIAL,
                                   :NOME_SOCIAL,
                                   :CPF_CNPJ,
                                   :DDD_01,
                                   :TELEFONE_01,
                                   :DDD_02,
                                   :TELEFONE_02,
                                   :CEP,
                                   :CIDADE,
                                   :UF,
                                   :LOGRADOURO,
                                   :NUMERO,
                                   :BAIRRO,
                                   :COMPLEMENTO,
                                   :CAIXA_POSTAL,
                                   :EMAIL_01,
                                   :SENHA,
                                   NULL,
                                   NULL,
                                   NULL,
                                   :ID_TIPO_TELEFONE_01,
                                   :ID_TIPO_TELEFONE_02,
                                   :ID_TIPO_EMAIL_01,
                                   0,
                                   0,
                                   :DATA_NASCIMENTO,
                                   NULL,
                                   NULL,
                                   NULL,
                                   NULL,
                                   NULL,
                                   :ID_USER_EXECUCAO,
                                   @vErro,
                                   @vQtdErros,
                                   @vRetorno)";
        $parametros_sql = array(":HASH_PREFEITURA"=>$_SESSION["param_referencia"],
                                ":NOME_OFICIAL"=>$param_nome_registro, 
                                ":NOME_SOCIAL"=>$param_nome_social, 
                                ":CPF_CNPJ"=>$param_cpf_numeros, 
                                ":DDD_01"=>$param_ddd01, 
                                ":TELEFONE_01"=>$param_telefone01, 
                                ":DDD_02"=>$param_ddd02, 
                                ":TELEFONE_02"=>$param_telefone02, 
                                ":CEP"=>$param_cep_numeros, 
                                ":CIDADE"=>$param_cidade, 
                                ":UF"=>$param_uf, 
                                ":LOGRADOURO"=>$param_logradouro, 
                                ":NUMERO"=>$param_numero, 
                                ":BAIRRO"=>$param_bairro, 
                                ":COMPLEMENTO"=>$param_complemento, 
                                ":CAIXA_POSTAL"=>$param_caixa_postal, 
                                ":EMAIL_01"=>$param_email, 
                                ":SENHA"=>$param_senha, 
                                ":ID_TIPO_TELEFONE_01"=>$param_tipo01, 
                                ":ID_TIPO_TELEFONE_02"=>$param_tipo02, 
                                ":ID_TIPO_EMAIL_01"=>$param_tipo_email,
                                ":DATA_NASCIMENTO"=>$param_data_nasc_formatada,
                                ":ID_USER_EXECUCAO"=>3);
        $stmt= $pdo->prepare($sql);
        $stmt->execute($parametros_sql);
        
        $vErro = ""; $vQtdErros = ""; $vRetorno = ""; 
        $sql = "select @vErro, @vQtdErros, @vRetorno";
        $stmt= $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $vErro = $result["@vErro"];
        $vQtdErros = $result["@vQtdErros"];
        $vRetorno = $result["@vRetorno"];
        
        if ($vQtdErros == "0")
        {
          //$vCamposObrigatorios = "<font color='blue font-size: 14px'>". $vRetorno ."</font>";
          echo("<font color='blue font-size: 16px'>Usuário cadastrado com sucesso. Pendente validação no e-mail de cadastro.</font>");
          echo("<script language='Javascript'>window.location = 'envio_email.php?param_municipe=". $vRetorno ."&param_tipo_mensagem=VLD'</script>");
        }
        else
        {
          //$vCamposObrigatorios = "<font color='red font-size: 14px'>". $vRetorno .' - '. $vErro ."</font>";
          $vCamposObrigatorios = "<font color='red font-size: 14px'>". $vErro ."</font>";
        }

      } 
      catch (PDOException $e) 
      {
        $e->getMessage();
        $vErroCodigo = $vErroCodigo ."Procedure proc_municipe. Erro: $e <br>";
      };
    };
	};
?>

<!DOCTYPE>
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Cadastro</title>
    <script type="text/javascript" src="./js/jquery.js"></script>
    <script type="text/javascript" src="./js/jquery.maskedinput.js"/></script>
    <script>
    function Carrega_Formulario()
    {
      $("#div_cabecalho").load("cabecalho_ajax.php", {param_funcao: 'carregar'});
    }
    
    function ValidarUsuario()
    {
      $("#div_cabecalho").load("cabecalho_ajax.php", {param_funcao: 'validar_acesso', param_email: $("#var_email").val(), param_senha: $("#var_senha").val()});
    }
    
    function Logof()
    {
      $("#div_cabecalho").load("cabecalho_ajax.php", {param_funcao: 'logof'});
    }
    
    $(document).ready(function(){
      $("#cp_cpf").mask("999.999.999-99");
      $("#cp_cep").mask("99.999-999");
    });
    
    function mascaraData( campo, e )
    {
      var kC = (document.all) ? event.keyCode : e.keyCode;
      var data = campo.value;
      
      if( kC!=8 && kC!=46 )
      {
        if( data.length==2 )
        {
          campo.value = data += '/';
        }
        else if( data.length==5 )
        {
          campo.value = data += '/';
        }
        else
          campo.value = data;
      }
    }
    
    function validacaoEmail(field) 
    {
      usuario = field.value.substring(0, field.value.indexOf("@"));
      dominio = field.value.substring(field.value.indexOf("@")+ 1, field.value.length);

      if ((usuario.length >=1) &&
          (dominio.length >=3) &&
          (usuario.search("@")==-1) &&
          (dominio.search("@")==-1) &&
          (usuario.search(" ")==-1) &&
          (dominio.search(" ")==-1) &&
          (dominio.search(".")!=-1) &&
          (dominio.indexOf(".") >=1)&&
          (dominio.lastIndexOf(".") < dominio.length - 1)) {
        document.getElementById("span_msg").innerHTML="";
      }
      else
      {
        document.getElementById("span_msg").innerHTML="<font style='color: #FF0000;'>E-mail inválido</font>";
      }
    }
    
    function comparar_senha()
    {
      var vSenha = document.getElementById("cp_senha").value;
      var vConferirSenha = document.getElementById("cp_conf_senha").value;
      if (vSenha != vConferirSenha) 
      {
        document.getElementById("span_msg").innerHTML = "<font style='color: #FF0000;'>Senha e Confirmação de senha estão diferentes.</font>";
      }
      else
      {
        document.getElementById("span_msg").innerHTML = "";
      }
    }
    
    function BuscaCPF()
    {
      if (document.getElementById("cp_cpf").value != "") 
      {
        $.getJSON("cadastro_ajax.php", {param_funcao: "busca_cpf", param_cpf: document.getElementById("cp_cpf").value}, function(data){
          if (data[0] != 0)
          {
            document.getElementById("span_msg").innerHTML = "<font color='red'>CPF " + document.getElementById("cp_cpf").value + " já consta no cadastro.</font>";
          };
        });
      };
    }
    
    function BuscaEmail()
    {
      if (document.getElementById("cp_email").value != "") 
      {
        $.getJSON("cadastro_ajax.php", {param_funcao: "busca_email", param_email: document.getElementById("cp_email").value}, function(data){
          if (data[0] != 0)
          {
            document.getElementById("span_msg").innerHTML = "<font color='red'>E-mail " + document.getElementById("cp_email").value + " já consta no cadastro.</font>";
          };
        });
      };
    }
    
    function copia_nome()
    {
      if ($("#cp_nome_social").val() == "")
      {
        document.getElementById("cp_nome_social").value = $("#cp_nome_registro").val();
      }
    }
    
    function proximo_campo(vCampo)
    {
      if (vCampo == "cp_numero")
      {
        if ($("#cp_bairro").val() != "")
        {
          document.getElementById("cp_email").focus();
        }
      }
    }
    </script>
    <style type="text/css">
	  @import "css.css";
    </style>
  </head>
  <body onLoad="Carrega_Formulario()">
    <div id="div_cabecalho"></div>
    <table width="100%" border="0" align="center" background="./img/fundo_principal.png">
      <tr>
        <td height="135px">
          <table width="1000px" border="0" align="center">
            <tr>
              <td class="titulo_azul_20" height="50px" colspan="2"><br><br>Cadastro de Acesso<br><br></td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
    <center>
    <form id="FA" name="FA" method="post" action="cadastro_municipe.php">
      <table width="800px" border="0" cellspacing="2" cellpadding="2">
				<tr>
          <td class="fonte12_esq"><b>Nome de Registro <span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="8"><input type="text" name="cp_nome_registro" id="cp_nome_registro" placeholder="Nome de Registro" value="<?php echo($param_nome_registro); ?>" size="90" onBlur="copia_nome();"></td>
        </tr>
				<tr>
          <td class="fonte12_esq"><b>Nome Social <span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="8"><input type="text" name="cp_nome_social" id="cp_nome_social" placeholder="Nome Social" value="<?php echo($param_nome_social); ?>" size="90"></td>
        </tr>
				<tr>
          <td class="fonte12_esq"><b>Nascimento <span style="color:red">*</span></b></td>
          <td class="fonte12_esq"><input type="text" name="cp_data_nasc" id="cp_data_nasc" placeholder="DD/MM/AAAA" value="<?php echo($param_data_nasc); ?>" size="10" maxlength="10" onkeypress="mascaraData( this, event )"></td>
          <td class="fonte12_esq"><b>CPF <span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="5"><input type="text" name="cp_cpf" id="cp_cpf" placeholder="CPF" value="<?php echo($param_cpf); ?>" size="11" maxlength="10" onBlur="BuscaCPF()"></td>
        </tr>  

				<tr>
          <td class="fonte12_esq"><b>DDD <span style="color:red">*</span></b></td>
          <td class="fonte12_esq"><input type="text" name="cp_ddd01" id="cp_ddd01" placeholder="DDD" value="<?php echo($param_ddd01); ?>" size="2" maxlength="2"></td>
          <td class="fonte12_esq"><b>Telefone <span style="color:red">*</span></b></td>
          <td class="fonte12_esq"><input type="text" name="cp_telefone01" id="cp_telefone01" placeholder="Telefone" value="<?php echo($param_telefone01); ?>" size="11" maxlength="9"></td>
          <td class="fonte12_esq"><b>DDD</b></td>
          <td class="fonte12_esq">
            <input type="text" name="cp_ddd02" id="cp_ddd02" placeholder="DDD" value="<?php echo($param_ddd02); ?>" size="2" maxlength="2">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Telefone</b>&nbsp;&nbsp;&nbsp;
            <input type="text" name="cp_telefone02" id="cp_telefone02" placeholder="Telefone" value="<?php echo($param_telefone02); ?>" size="11" maxlength="9">
          </td>
        </tr>

				<tr>
          <td class="fonte12_esq"><b>CEP <span style="color:red">*</span></b></td>
          <td class="fonte12_esq"><input type="text" name="cp_cep" id="cp_cep" placeholder="CEP" value="<?php echo($param_cep); ?>" size="8"></td>
          <td class="fonte12_esq"><b>Estado <span style="color:red">*</span></b></td>
          <td class="fonte12_esq">
            <select name='cp_uf' id='cp_uf'>
              <option value='AC' <?php if ('AC' == $param_uf) { ECHO("SELECTED"); }; ?>>Acre</option>
              <option value='AL' <?php if ('AL' == $param_uf) { ECHO("SELECTED"); }; ?>>Alagoas</option>
              <option value='AP' <?php if ('AP' == $param_uf) { ECHO("SELECTED"); }; ?>>Amapa</option>
              <option value='AM' <?php if ('AM' == $param_uf) { ECHO("SELECTED"); }; ?>>Amazonas</option>
              <option value='BA' <?php if ('BA' == $param_uf) { ECHO("SELECTED"); }; ?>>Bahia</option>
              <option value='CE' <?php if ('CE' == $param_uf) { ECHO("SELECTED"); }; ?>>CEARA</option>
              <option value='DF' <?php if ('DF' == $param_uf) { ECHO("SELECTED"); }; ?>>Distrito Federal</option>
              <option value='ES' <?php if ('ES' == $param_uf) { ECHO("SELECTED"); }; ?>>Espirito Santo</option>
              <option value='GO' <?php if ('GO' == $param_uf) { ECHO("SELECTED"); }; ?>>Goias</option>
              <option value='MA' <?php if ('MA' == $param_uf) { ECHO("SELECTED"); }; ?>>Maranhao</option>
              <option value='MT' <?php if ('MT' == $param_uf) { ECHO("SELECTED"); }; ?>>Mato Grosso</option>
              <option value='MS' <?php if ('MS' == $param_uf) { ECHO("SELECTED"); }; ?>>Mato Grosso do Sul</option>
              <option value='MG' <?php if ('MG' == $param_uf) { ECHO("SELECTED"); }; ?>>Minas Gerais</option>
              <option value='PA' <?php if ('PA' == $param_uf) { ECHO("SELECTED"); }; ?>>Para</option>
              <option value='PB' <?php if ('PB' == $param_uf) { ECHO("SELECTED"); }; ?>>Paraiba</option>
              <option value='PR' <?php if ('PR' == $param_uf) { ECHO("SELECTED"); }; ?>>Parana</option>
              <option value='PE' <?php if ('PE' == $param_uf) { ECHO("SELECTED"); }; ?>>Pernambuco</option>
              <option value='PI' <?php if ('PI' == $param_uf) { ECHO("SELECTED"); }; ?>>Piaui</option>
              <option value='RJ' <?php if ('RJ' == $param_uf) { ECHO("SELECTED"); }; ?>>Rio de Janeiro</option>
              <option value='RN' <?php if ('RN' == $param_uf) { ECHO("SELECTED"); }; ?>>Rio Grande do Norte</option>
              <option value='RS' <?php if ('RS' == $param_uf) { ECHO("SELECTED"); }; ?>>Rio Grande do Sul</option>
              <option value='RO' <?php if ('RO' == $param_uf) { ECHO("SELECTED"); }; ?>>Rondonia</option>
              <option value='RR' <?php if ('RR' == $param_uf) { ECHO("SELECTED"); }; ?>>Roraima</option>
              <option value='SC' <?php if ('SC' == $param_uf) { ECHO("SELECTED"); }; ?>>Santa Catarina</option>
              <option value='SP' <?php if ('SP' == $param_uf) { ECHO("SELECTED"); }; ?>>São Paulo</option>
              <option value='SE' <?php if ('SE' == $param_uf) { ECHO("SELECTED"); }; ?>>Sergipe</option>
              <option value='TO' <?php if ('TO' == $param_uf) { ECHO("SELECTED"); }; ?>>Tocantins</option>
            </select>
          </td>
          <td class="fonte12_esq"><b>Cidade <span style="color:red">*</span></b></td>
          <td class="fonte12_esq"><input type="text" name="cp_cidade" id="cp_cidade" placeholder="Cidade" value="<?php echo($param_cidade); ?>" size="30"></td>
        </tr>

				<tr>
          <td class="fonte12_esq"><b>Logradouro</b></td>
          <td class="fonte12_esq" colspan="3"><input type="text" name="cp_logradouro" id="cp_logradouro" placeholder="Logradouro" value="<?php echo($param_logradouro); ?>" size="40"></td>
          <td class="fonte12_esq"><b>Número</b></td>
          <td class="fonte12_esq">
            <input type="text" name="cp_numero" id="cp_numero" placeholder="Numero" value="<?php echo($param_numero); ?>" size="5" onBlur="proximo_campo('cp_numero');">
            &nbsp;&nbsp;&nbsp;&nbsp;<b>Caixa Postal</b>&nbsp;&nbsp;&nbsp;
            <input type="text" name="cp_caixa_postal" id="cp_caixa_postal" placeholder="Numero" value="<?php echo($param_caixa_postal); ?>" size="5">
          </td>
        </tr>
				<tr>
          <td class="fonte12_esq"><b>Bairro</b></td>
          <td class="fonte12_esq" colspan="3"><input type="text" name="cp_bairro" id="cp_bairro" placeholder="Bairro" value="<?php echo($param_bairro); ?>" size="40"></td>
          <td class="fonte12_esq"><b>Complemento</b></td>
          <td class="fonte12_esq"><input type="text" name="cp_complemento" id="cp_complemento" placeholder="Complemento" value="<?php echo($param_complemento); ?>" size="30"></td>
        </tr>

				<tr>
          <td class="fonte12_esq"><b>E-mail <span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="3"><input type="text" name="cp_email" id="cp_email" placeholder="E-mail" value="<?php echo($param_email); ?>" size="40" onBlur="BuscaEmail()"></td>
          <td class="fonte12_esq"><b>Conf. de E-mail <span style="color:red">*</span></b></td>
          <td class="fonte12_esq"><input type="text" name="cp_conf_email" id="cp_conf_email" placeholder="Confirmação de E-mail" value="<?php echo($param_email); ?>" size="30" onBlur="ConfEmail()"></td>
        </tr>
				<tr>
          <td class="fonte12_esq"><b>Senha <span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="2"><input type="password" name="cp_senha" id="cp_senha" value="<?php echo($param_senha); ?>" size="15" minlength="6" onchange="comparar_senha()"></td>
          <td class="fonte12_esq"><b>Confirmação de Senha <span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="2"><input type="password" name="cp_conf_senha" id="cp_conf_senha" value="<?php echo($param_conf_senha); ?>" size="15" minlength="6" onchange="comparar_senha()"><span id="span_msg_senha"></span></td>
        </tr>
				<tr>
          <td class="fonte14" colspan="6"><span id="span_msg"><?php echo($vCamposObrigatorios); ?></span></td>
        </tr>
				<tr>
          <td class="fonte14" colspan="6"><input type="submit" class="button_padrao" name="bt_gravar" value="&nbsp;&nbsp;Gravar&nbsp;&nbsp;"></td>
        </tr>
      </table>
    </form>
    <?php echo($vErroCodigo); ?>
  </body>
</html>