<?php	
  session_start();
  $vResultado = "";
	if ($_REQUEST["param_funcao"] == "logof") 
  { 
    session_destroy();
    echo("<script language='Javascript'>window.location = 'index.php'</script>");
  };
  
  require_once("seg_conexao.php");
  
	if ($_REQUEST["param_funcao"] == "validar_acesso") 
  {  
    try 
    {
      $pdo = connect();
      $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch(PDOException $e) {
      $e->getMessage();
      echo "<span class='fonte_doze_negrito_erro'>[ Erro $e ]</span>";
      exit;
    };
     
	  try 
	  {
      $vEmail = $_REQUEST['param_email'];
      $vSenha = $_REQUEST['param_senha'];
       
      $sql = "select count(1) as qtde,
                     max(u.usuario) as usuario,
                     max(u.tipo_usuario) as tipo_usuario,
                     max(p.nome_social) as nome_social,
                     max(u.cod_pessoa) as cod_pessoa,
                     max(u.cod_usuario) as cod_usuario
                from usuario u
                      left join pessoa p on (p.cod_pessoa = u.cod_pessoa)
               where u.senha = :SENHA
                 and u.usuario = :USUARIO";
      $parametros_sql = array(":SENHA"=>$vSenha, 
                              ":USUARIO"=>$vEmail);
      $stmt= $pdo->prepare($sql);
      $stmt->execute($parametros_sql);
      $result = $stmt->fetch(PDO::FETCH_ASSOC);
	  } catch(PDOException $e) {
	  	$e->getMessage();
	  	echo "<span class='fonte_doze_negrito_erro'>[ Erro $e ]</span>";
	  	exit;
	  };
     
    if ($result["qtde"] == "0") { $vQtdErros = 1; };
     
	  try 
	  {
      if ($vQtdErros == 0) 
      { 
        $_SESSION['param_usuario'] = $result["usuario"];
        $_SESSION['param_tipo_usuario'] = $result["tipo_usuario"];
        $_SESSION['param_nome_usuario'] = $result["nome_social"];
        $_SESSION['param_email'] = $result["usuario"];
        $_SESSION['param_cod_pessoa'] = $result["cod_pessoa"];
        $_SESSION['param_cod_usuario'] = $result["cod_usuario"];
                   
        $pdo = null;
        
        if($_SESSION['param_tipo_usuario'] == "CL")
        {
          echo("<script language='Javascript'>window.location = 'menu_colaborador.php'</script>");
        }
      } 
      else 
      { 
        
        $vResultado = "<br>E-mail ou Senha não esta correto."; 
        if (isset($_SESSION["param_usuario"])) { unset($_SESSION["param_usuario"]); }
        if (isset($_SESSION["param_nome_usuario"])) { unset($_SESSION["param_nome_usuario"]); }
        if (isset($_SESSION["param_email"])) { unset($_SESSION["param_email"]); }
        if (isset($_SESSION["param_cod_pessoa"])) { unset($_SESSION["param_cod_pessoa"]); }
        $pdo = null;
      };
	  } catch(PDOException $e) {
	  	$e->getMessage();
	  	echo "<span class='fonte_doze_negrito_erro'>[ Erro $e ]</span>";
	  	exit;
	  };
    $pdo = "";
  };  

 	if ($_REQUEST["param_funcao"] == "carregar" or $_REQUEST["param_funcao"] == "validar_acesso" or $_REQUEST["param_funcao"] == "logof") 
  {
    
    try 
    {
      $pdo = connect();
      $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch(PDOException $e) {
      $e->getMessage();
      echo "<span class='fonte_doze_negrito_erro'>[ Erro $e ]</span>";
      exit;
    };
    
    if (!isset($_SESSION['param_usuario']))
    {  
?>
  <script language="javascript">
    function Logof()
    {
      $("#div_cabecalho").load("cabecalho_ajax.php", {param_funcao: 'logof'});
    }
  </script>
  <table width="1000px" border="0" align="center">
    <tr>
      <td align="left">
        <a href="index.php">
          <img src = "./img/modernizando_cidades.png"  height="90" title="Modernizando Cidades" border="0"/></a>
      </td>
      <td>
        <table border="0" align="right">
          <tr>
            <td class="fonte12_esq fonte_cinza_escruro"><b>E-mail:</b></td>
            <td class="fonte12_esq" colspan="2"><input type="text" id="var_email" name="var_email" size="20" placeholder="Digite o e-mail" class="form-control" style="max-width:200px; max-height:20px;"></td>
          </tr>
          <tr>
            <td class="fonte12_esq fonte_cinza_escruro"><b>Senha:</b></td>
            <td class="fonte12_esq" colspan="2"><input type="password" id="var_senha" name="var_senha" size="20" minlength="8" required placeholder="Digite a senha" class="form-control" style="max-width:200px; max-height:20px;"></td>
          </tr>
          <tr>
            <td class="fonte10_esq" colspan="2">
              <a href="cadastro_acesso.php">Não Tenho Cadastro</a><br>
              <!--<a href="esqueci_senha.php">Esqueci a Senha</a>-->
            </td>
            <td class="fonte10_dir">
              <button class="button_preto_fino" onclick="ValidarUsuario()">&nbsp;&nbsp;Validar Acesso&nbsp;&nbsp;</button><?PHP ECHO($vResultado); ?>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
<?php 
    } 
    else 
    { 
?>
  <script language="javascript">
    function Logof()
    {
      $("#div_cabecalho").load("cabecalho_ajax.php", {param_funcao: 'logof'});
    }
  </script>
  <table width="1000px" border="0" align="center">
    <tr>
      <td align="left">
        <a href="index.php">
          <img src = "./img/modernizando_cidades.png" height="90" title="Modernizando Cidades" border="0"/></a>
      </td>
      <td valign="bottom">
        <table border="0" align="right">
          <tr>
            <td class="fonte11" colspan="2">
<?php if ($_SESSION['param_tipo_usuario'] == "CL") { ?>
              <a href="menu_colaborador.php"><img src = "./img/contacts.png" title="Menu do Colaborador" border="0"/></a>
<?php } else { ?>
              <a href="cadastro_candidato.php"><img src = "./img/contacts.png" title="Cadastro do Candidato" border="0"/></a>
<?php } ?>
            </td>
          </tr>
          <tr>
            <td class="fonte11" colspan="2"><?php echo($_SESSION['param_nome_usuario']); ?></td>
          </tr>
          <tr>
            <td class="fonte11" colspan="2"><a href="javascript:Logof();">Desconectar</a></td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
<?php 
    };
  };
?>