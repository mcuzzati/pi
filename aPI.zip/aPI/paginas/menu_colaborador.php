<?php	
  session_start();
  if (!isset($_SESSION['param_usuario']))
  { 
    session_destroy();
    echo("<script language='Javascript'>window.location = 'index.php'</script>");
  }
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Menu do Colaborador</title>
<style type="text/css">
@import "css.css";
</style>
<script type="text/javascript" src="./js/jquery.maskedinput.js" ></script>
<script type="text/javascript" src="./js/jquery.js"></script>
<script type="text/javascript" src="./js/jquery.form.js"></script>
<script type="text/javascript" src="./js/jquery.selects.js"></script>
<script language="javascript">
  function Carrega_Formulario()
  {
    $("#div_cabecalho").load("cabecalho_ajax.php", {param_funcao: 'carregar'});
  }
</script>
</head>
<body onLoad="Carrega_Formulario()">
  <center>
  <div id="div_cabecalho"></div> 
  <table width="100%" border="0" align="center" background="./img/fundo_principal.png">
    <tr>
      <td height="135px">
        <table width="1000px" border="0" align="center">
          <tr>
            <td class="titulo_azul_20" height="50px" colspan="2"><br><br><br><br></td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
  <br>
  <table width="1000px" border="0" cellspacing="15" cellpadding="15">
    <tr height="200px">
      <td width="33%" bgcolor="#a6bce8" class="titulo_padrao arredondamento_superior arredondamento_inferior"><a href="lista_usuario_sistema.php">Usuários</a></td>
      <td width="34%" bgcolor="#a6bce8" class="titulo_padrao arredondamento_superior arredondamento_inferior"><a href="lista_vagas_emprego.php">Vagas de Emprego</a></td>
      <td width="33%" bgcolor="#a6bce8" class="titulo_padrao arredondamento_superior arredondamento_inferior"><a href="lista_candidato.php">Candidatos</a></td>
    </tr>
  </table>
</body>
</html>
