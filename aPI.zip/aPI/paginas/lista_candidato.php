<?php	
  session_start();
  if (!isset($_SESSION['param_usuario']) or $_SESSION['param_tipo_usuario'] <> "CL")
  { 
    session_destroy();
    echo("<script language='Javascript'>window.location = 'index.php'</script>");
  }

  require_once("seg_conexao.php");
    
  try 
	{  
	  $pdo = connect();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	}
	catch(PDOException $e)
	{
		$e->getMessage();
		echo "<span class='fonte_doze_negrito_erro'>Conectando com Banco de Dados. [ Erro $e ]</span>";
		exit;
	};
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Usuário Candidato</title>
<style type="text/css">
  @import "css.css";
  @import "./font-awesome/css/all.min.css"
</style>
<script type="text/javascript" src="./js/jquery.maskedinput.js" ></script>
<script type="text/javascript" src="./js/jquery.js"></script>
<script type="text/javascript" src="./js/jquery.form.js"></script>
<script type="text/javascript" src="./js/jquery.selects.js"></script>
<script language="javascript">
  function Carrega_Formulario()
  {
    $("#div_cabecalho").load("cabecalho_ajax.php", {param_funcao: 'carregar'});
  }
</script>
</head>
<body onLoad="Carrega_Formulario()">
  <center>
  <div id="div_cabecalho"></div> 
  <table width="100%" border="0" align="center" background="./img/fundo_principal.png">
    <tr>
      <td height="135px">
        <table width="1000px" border="0" align="center">
          <tr>
            <td class="titulo_azul_20" height="50px" colspan="2"><br><br><br><br></td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
  <br>
  <table width="1000px" border="0" cellspacing="2" cellpadding="2">
    <tr height="40px">
      <td bgcolor="#a6bce8" class="titulo_padrao arredondamento_superior" colspan="2">
        Lista de Candidatos as Vagas de Emprego
      </td>
    </tr>
    <tr height="20px">
      <td bgcolor="#a6bce8" class="titulo_padrao">Candidato</td>
      <td bgcolor="#a6bce8" class="titulo_padrao">Alteração</td>
    </tr>
<?php  
  try 
  {
		$sql = "select p.cod_pessoa,
                   p.nome_social,
                   pa.nome_social as usuario_alteracao,
                   DATE_FORMAT(p.alteracao,'%d/%m/%Y %H:%i') as alteracao
              from usuario u
                    inner join pessoa p on (p.cod_pessoa = u.cod_pessoa)
                    inner join usuario ua on (ua.cod_usuario = p.id_usuario_alteracao)
                    inner join pessoa pa on (pa.cod_pessoa = ua.cod_pessoa)
             where u.tipo_usuario = 'CN'
             order by p.nome_social";
    $stmt= $pdo->prepare($sql);
    $stmt->execute();
  }
  catch(PDOException $e)
  {
    $e->getMessage();
    echo "<span class='fonte_doze_negrito_erro'>[ Erro $e ]</span>";
    exit;
  };
  
  $vContador = 0; $vCorLinha == "#bfc8db";
  while ($result = $stmt->fetch(PDO::FETCH_ASSOC)) 
  {
    $vContador = ($vContador + 1);
    if ($vCorLinha == "#bfc8db") { $vCorLinha = "#ffffff"; } else { $vCorLinha = "#bfc8db"; };
?>
    <tr height="40px">
      <td bgcolor="<?php echo($vCorLinha); ?>" class="fonte14_esq">&nbsp;&nbsp;&nbsp;<?php echo($result["nome_social"]); ?></td>
      <td bgcolor="<?php echo($vCorLinha); ?>" class="fonte12_esq" width="220px">&nbsp;&nbsp;&nbsp;Alterado em: <?php echo($result["alteracao"] ."<br>&nbsp;&nbsp;&nbsp;Por: ". $result["usuario_alteracao"]); ?></td>
    </tr>
<?php
  };
  
  if ($vContador == 0)
  {
?>
    <tr height="40px">
      <td bgcolor="<?php echo($vCorLinha); ?>" class="fonte14" colspan="4">Não há candidatos</td>
    </tr>
<?php
  }
?>
    <tr height="15px">
      <td bgcolor="#a6bce8" class="titulo_padrao arredondamento_inferior" colspan="2"></td>
    </tr>
  </table>
</body>
</html>
