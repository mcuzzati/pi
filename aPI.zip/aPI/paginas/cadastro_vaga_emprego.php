<?PHP	
  session_start();
  if (!isset($_SESSION['param_usuario']) or $_SESSION['param_tipo_usuario'] <> "CL")
  { 
    session_destroy();
    echo("<script language='Javascript'>window.location = 'index.php'</script>");
  }
  
	if (!empty($_REQUEST['param_cod_vaga'])) { $param_cod_vaga = trim($_REQUEST['param_cod_vaga']); } else { $param_cod_vaga = "0"; };
  if (!empty($_REQUEST['op'])) { $op = trim($_REQUEST['op']); } else { $op = "X"; };
  
	require_once("seg_conexao.php");
  require_once("funcoes.php");
		
  try 
  {
    $pdo = connect();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  } catch(PDOException $e) {
    $e->getMessage();
    echo "<span class='fonte_doze_negrito_erro'>[ Erro $e ]</span>";
    exit;
  };
    
  $vErroCodigo = "";
    
  $param_departamento = "";
  $param_descritivo_vaga = "";
  $param_conhecimento_necessario = "";
  $param_grau_escolar = "";
  $param_grau_escolar_minimo = "";
  $param_beneficio = "";
  $param_salario = "";
  
  $vCamposObrigatorios = "";
  
	if($op == "EX")
  { 
    try
    {
      $sql = "delete from vaga_emprego_x_elegivel
               where cod_vaga_emprego = :COD_VAGA_EMPREGO";
      $parametros_sql = array(":COD_VAGA_EMPREGO"=>$param_cod_vaga);
      $stmt= $pdo->prepare($sql);
      $stmt->execute($parametros_sql);

      $sql = "delete from vaga_emprego
               where cod_vaga_emprego = :COD_VAGA_EMPREGO";
      $parametros_sql = array(":COD_VAGA_EMPREGO"=>$param_cod_vaga);
      $stmt= $pdo->prepare($sql);
      $stmt->execute($parametros_sql);
      if( $stmt->rowCount() == 0 )
      {
        $vCamposObrigatorios = "<font color='red font-size: 14px'>Exclusão de vaga de emprego não foi concluída. Tente novamente.</font>";
      }
      else
      {
        echo("<script language='Javascript'>window.location = 'lista_vagas_emprego.php'</script>");
      }
    } 
    catch (PDOException $e) 
    {
      $e->getMessage();
      $vErroCodigo = $vErroCodigo ."Exclusão de pessoa. Erro: $e <br>";
    };
  }
	elseif(isset($_REQUEST['bt_voltar']))
  { 
    echo("<script language='Javascript'>window.location = 'lista_vagas_emprego.php'</script>");
  }
	elseif(isset($_REQUEST['bt_gravar']))
  {   
    if (!empty($_REQUEST['cp_empresa'])) 	               { $param_empresa = trim($_REQUEST['cp_empresa']); };
    if (!empty($_REQUEST['cp_departamento'])) 	         { $param_departamento = trim($_REQUEST['cp_departamento']); };
    if (!empty($_REQUEST['cp_ocupacao'])) 	             { $param_ocupacao = trim($_REQUEST['cp_ocupacao']); };
    if (!empty($_REQUEST['cp_descritivo_vaga']))         { $param_descritivo_vaga = trim($_REQUEST['cp_descritivo_vaga']); };
    if (!empty($_REQUEST['cp_conhecimento_necessario'])) { $param_conhecimento_necessario = trim($_REQUEST['cp_conhecimento_necessario']); };
    if (!empty($_REQUEST['cp_grau_escolar'])) 		       { $param_grau_escolar = trim($_REQUEST['cp_grau_escolar']); };
    if (!empty($_REQUEST['cp_grau_escolar_minimo'])) 		 { $param_grau_escolar_minimo = trim($_REQUEST['cp_grau_escolar_minimo']); } else { $param_grau_escolar_minimo = null; };
    if (!empty($_REQUEST['cp_beneficio'])) 					     { $param_beneficio = trim($_REQUEST['cp_beneficio']); };
    if (!empty($_REQUEST['cp_salario'])) 	               { $param_salario = trim($_REQUEST['cp_salario']); $param_salario_gv = valor_banco(trim($_REQUEST['cp_salario'])); };
       
    $vSeparador = "";
    if (empty($param_empresa)) { $vCamposObrigatorios = "Empresa"; $vSeparador = ", "; };
    if (empty($param_departamento)) { $vCamposObrigatorios = "Departamento"; $vSeparador = ", "; };
    if (empty($param_ocupacao)) { $vCamposObrigatorios = "Ocupação"; $vSeparador = ", "; };
    if (empty($param_conhecimento_necessario))   { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Conhecimento Necessário"; $vSeparador = ", "; };
    
    if (empty($param_grau_escolar))         { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Grau de Escolaridade"; $vSeparador = ", "; };
    if (empty($param_salario))    { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Salário"; $vSeparador = ", "; };
    
    if (!empty($vCamposObrigatorios))
    {
      $vCamposObrigatorios = $vCamposObrigatorios ." são campos obrigatório(s)."; 
      
      $vCamposObrigatorios = "<font color='red' font-size: 14px>". $vCamposObrigatorios ."</font>"; 
    }
    
    if (empty($vCamposObrigatorios))
    {    
      try 
      { // CADASTRO DE VAGA
        $sql = "insert into vaga_emprego
                (alteracao, id_usuario_alteracao, empresa, departamento cod_ocupacao, descritivo_vaga, conhecimento_necessario, 
                 beneficios, salario, cod_grau_escolaridade, cod_grau_escolaridade_minimo, status)
                values (now(), :ID_USER_EXECUCAO, :EMPRESA, :DEPARTAMENTO, :COD_OCUPACAO, :DESCRITIVO_VAGA, :CONHECIMENTO_NECESSARIO, 
                        :BENEFICIOS, :SALARIO, :COD_GRAU_ESCOLARIDADE, :COD_GRAU_ESCOLARIDADE_MINIMO, 'A')";
        $parametros_sql = array(":ID_USER_EXECUCAO"=>$_SESSION['param_cod_usuario'],
                                ":EMPRESA"=>$param_empresa, 
                                ":DEPARTAMENTO"=>$param_departamento, 
                                ":COD_OCUPACAO"=>$param_ocupacao, 
                                ":DESCRITIVO_VAGA"=>$param_descritivo_vaga, 
                                ":CONHECIMENTO_NECESSARIO"=>$param_conhecimento_necessario, 
                                ":BENEFICIOS"=>$param_beneficio, 
                                ":SALARIO"=>$param_salario_gv, 
                                ":COD_GRAU_ESCOLARIDADE"=>$param_grau_escolar, 
                                ":COD_GRAU_ESCOLARIDADE_MINIMO"=>$param_grau_escolar_minimo);
        $stmt= $pdo->prepare($sql);
        $stmt->execute($parametros_sql);
        $vCodVagaEmprego = $pdo->lastInsertId('cod_vaga_emprego');
        if( $stmt->rowCount() == 0 )
        {
          $vCamposObrigatorios = "<font color='red font-size: 14px'>Cadastro não foi concluído. Tente novamente.</font>";
        }
        else
        {
          echo("<font color='blue font-size: 16px'>Vaga de emprego cadastrada com sucesso.</font>");
          echo("<script language='Javascript'>window.location = 'cadastro_vaga_emprego.php?param_cod_vaga=". $vCodVagaEmprego ."'</script>");
        }
      } 
      catch (PDOException $e) 
      {
        $e->getMessage();
        $vErroCodigo = $vErroCodigo ."Cadastro de usuário. Erro: $e <br>";
      };
    };
	}
  elseif(isset($_REQUEST['bt_alterar']))
  {   
    if (!empty($_REQUEST['cp_empresa'])) 	               { $param_empresa = trim($_REQUEST['cp_empresa']); };
    if (!empty($_REQUEST['cp_departamento'])) 	         { $param_departamento = trim($_REQUEST['cp_departamento']); };
    if (!empty($_REQUEST['cp_ocupacao'])) 	             { $param_ocupacao = trim($_REQUEST['cp_ocupacao']); };
    if (!empty($_REQUEST['cp_descritivo_vaga']))         { $param_descritivo_vaga = trim($_REQUEST['cp_descritivo_vaga']); };
    if (!empty($_REQUEST['cp_conhecimento_necessario'])) { $param_conhecimento_necessario = trim($_REQUEST['cp_conhecimento_necessario']); };
    if (!empty($_REQUEST['cp_grau_escolar'])) 		       { $param_grau_escolar = trim($_REQUEST['cp_grau_escolar']); };
    if (!empty($_REQUEST['cp_grau_escolar_minimo'])) 		 { $param_grau_escolar_minimo = trim($_REQUEST['cp_grau_escolar_minimo']); };
    if (!empty($_REQUEST['cp_beneficio'])) 					     { $param_beneficio = trim($_REQUEST['cp_beneficio']); };
    if (!empty($_REQUEST['cp_salario'])) 	               { $param_salario = trim($_REQUEST['cp_salario']); $param_salario_gv = valor_banco(trim($_REQUEST['cp_salario'])); };
    if (!empty($_REQUEST['cp_status'])) 					       { $param_status = trim($_REQUEST['cp_status']); };
       
    $vSeparador = "";
    if (empty($param_empresa)) { $vCamposObrigatorios = "Empresa"; $vSeparador = ", "; };
    if (empty($param_departamento)) { $vCamposObrigatorios = "Departamento"; $vSeparador = ", "; };
    if (empty($param_ocupacao)) { $vCamposObrigatorios = "Ocupação"; $vSeparador = ", "; };
    if (empty($param_conhecimento_necessario))   { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Conhecimento Necessário"; $vSeparador = ", "; };
    
    if (empty($param_grau_escolar))         { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Grau de Escolaridade"; $vSeparador = ", "; };
    if (empty($param_salario))    { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Salário"; $vSeparador = ", "; };
    if (empty($param_status))    { $vCamposObrigatorios = $vCamposObrigatorios . $vSeparador ."Situação"; $vSeparador = ", "; };
    
    if (!empty($vCamposObrigatorios))
    {
      $vCamposObrigatorios = $vCamposObrigatorios ." são campos obrigatório(s)."; 
      
      $vCamposObrigatorios = "<font color='red' font-size: 14px>". $vCamposObrigatorios ."</font>"; 
    }
    
    if (empty($vCamposObrigatorios))
    {   
      try 
      { // CADASTRO DE VAGA
        $sql = "update vaga_emprego
                   set alteracao = now(),
                       id_usuario_alteracao = :ID_USER_EXECUCAO,
                       empresa = :EMPRESA,
                       departamento = :DEPARTAMENTO,
                       cod_ocupacao = :COD_OCUPACAO,
                       descritivo_vaga = :DESCRITIVO_VAGA,
                       conhecimento_necessario = :CONHECIMENTO_NECESSARIO,
                       beneficios = :BENEFICIOS,
                       salario = :SALARIO,
                       cod_grau_escolaridade = :COD_GRAU_ESCOLARIDADE,
                       cod_grau_escolaridade_minimo = :COD_GRAU_ESCOLARIDADE_MINIMO,
                       status = :STATUS
                where cod_vaga_emprego = :COD_VAGA_EMPREGO";
        $parametros_sql = array(":ID_USER_EXECUCAO"=>$_SESSION['param_cod_usuario'],
                                ":EMPRESA"=>$param_empresa, 
                                ":DEPARTAMENTO"=>$param_departamento, 
                                ":COD_OCUPACAO"=>$param_ocupacao,
                                ":DESCRITIVO_VAGA"=>$param_descritivo_vaga, 
                                ":CONHECIMENTO_NECESSARIO"=>$param_conhecimento_necessario, 
                                ":BENEFICIOS"=>$param_beneficio, 
                                ":SALARIO"=>$param_salario_gv, 
                                ":COD_GRAU_ESCOLARIDADE"=>$param_grau_escolar, 
                                ":COD_GRAU_ESCOLARIDADE_MINIMO"=>$param_grau_escolar_minimo,
                                ":STATUS"=>$param_status,
                                ":COD_VAGA_EMPREGO"=>$param_cod_vaga);
        $stmt= $pdo->prepare($sql);
        $stmt->execute($parametros_sql);
        if( $stmt->rowCount() == 0 )
        {
          $vCamposObrigatorios = "<font color='red font-size: 14px'>Atualização não foi concluída. Tente novamente.</font>";
        }
        else
        {
          $vCamposObrigatorios = "<font color='red font-size: 14px'>Atualizado com sucesso.</font>";
        }
      } 
      catch (PDOException $e) 
      {
        $e->getMessage();
        $vErroCodigo = $vErroCodigo ."Cadastro de usuário. Erro: $e <br>";
      };
      
    };
	}
  else
  {  
    if (!empty($param_cod_vaga))
    { // BUSCA DADOS DA BASE    
      try 
      {
        $sql = "select v.cod_vaga_emprego,
                       v.empresa,
                       v.departamento,
                       v.cod_ocupacao,
                       v.descritivo_vaga,
                       v.conhecimento_necessario,
                       v.beneficios,
                       replace(v.salario,'.',',') as salario,
                       v.cod_grau_escolaridade,
                       v.cod_grau_escolaridade_minimo,
                       v.status,
                       pa.nome_social as usuario_alteracao,
                       DATE_FORMAT(v.alteracao,'%d/%m/%Y %H:%i') as alteracao
                  from vaga_emprego v
                        inner join usuario ua on (ua.cod_usuario = v.id_usuario_alteracao)
                        inner join pessoa pa on (pa.cod_pessoa = ua.cod_pessoa)
                  where v.cod_vaga_emprego = :COD_VAGA_EMPREGO";
        $parametros_sql = array(":COD_VAGA_EMPREGO"=>$param_cod_vaga);
        $stmt= $pdo->prepare($sql);
        $stmt->execute($parametros_sql);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!empty($result["cod_vaga_emprego"]))
        {  
          $param_empresa = $result["empresa"];
          $param_departamento = $result["departamento"];
          $param_ocupacao = $result["cod_ocupacao"];
          $param_descritivo_vaga = $result["descritivo_vaga"];
          $param_conhecimento_necessario = $result["conhecimento_necessario"];
          $param_grau_escolar = $result["cod_grau_escolaridade"];
          $param_grau_escolar_minimo = $result["cod_grau_escolaridade_minimo"];
          $param_beneficio = $result["beneficios"];
          $param_salario = $result["salario"];
          if ($result["status"] == "A") { $vStatusAberto = "SELECTED"; $vStatusFechado = ""; } else { $vStatusAberto = ""; $vStatusFechado = "SELECTED"; };
          
          $vUltimoAlterador = "Ultima alteração foi realizada em ". $result["alteracao"] ." por ". $result["usuario_alteracao"];
        };
        
      } catch(PDOException $e) {
        $e->getMessage();
        echo "<span class='fonte_doze_negrito_erro'>[ Erro $e ]</span>";
        exit;
      };
    }
  };
?>

<!DOCTYPE>
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Vaga de Emprego</title>
    <script type="text/javascript" src="./js/jquery.js"></script>
    <script type="text/javascript" src="./js/jquery.maskedinput.js"/></script>
    <script>
    function Carrega_Formulario()
    {
      $("#div_cabecalho").load("cabecalho_ajax.php", {param_funcao: 'carregar'});
    }
    
    function ValidarUsuario()
    {
      $("#div_cabecalho").load("cabecalho_ajax.php", {param_funcao: 'validar_acesso', param_email: $("#var_email").val(), param_senha: $("#var_senha").val()});
    }
    
    $(document).ready(function(){
      $("#cp_cpf").mask("999.999.999-99");
      $("#cp_cep").mask("99.999-999");
    });
    
    function mascaraData( campo, e )
    {
      var kC = (document.all) ? event.keyCode : e.keyCode;
      var data = campo.value;
      
      if( kC!=8 && kC!=46 )
      {
        if( data.length==2 )
        {
          campo.value = data += '/';
        }
        else if( data.length==5 )
        {
          campo.value = data += '/';
        }
        else
          campo.value = data;
      }
    }
    
    function validacaoEmail(field) 
    {
      usuario = field.value.substring(0, field.value.indexOf("@"));
      dominio = field.value.substring(field.value.indexOf("@")+ 1, field.value.length);

      if ((usuario.length >=1) &&
          (dominio.length >=3) &&
          (usuario.search("@")==-1) &&
          (dominio.search("@")==-1) &&
          (usuario.search(" ")==-1) &&
          (dominio.search(" ")==-1) &&
          (dominio.search(".")!=-1) &&
          (dominio.indexOf(".") >=1)&&
          (dominio.lastIndexOf(".") < dominio.length - 1)) {
        document.getElementById("span_msg").innerHTML="";
      }
      else
      {
        document.getElementById("span_msg").innerHTML="<font style='color: #FF0000;'>E-mail inválido</font>";
      }
    }
    
    function comparar_senha()
    {
      var vSenha = document.getElementById("cp_senha").value;
      var vConferirSenha = document.getElementById("cp_conf_senha").value;
      if (vSenha != vConferirSenha) 
      {
        document.getElementById("span_msg").innerHTML = "<font style='color: #FF0000;'>Senha e Confirmação de senha estão diferentes.</font>";
      }
      else
      {
        document.getElementById("span_msg").innerHTML = "";
      }
    }
    
    function comparar_email()
    {
      var vSenha = document.getElementById("cp_email").value;
      var vConferirSenha = document.getElementById("cp_conf_email").value;
      if (vSenha != vConferirSenha) 
      {
        document.getElementById("span_msg").innerHTML = "<font style='color: #FF0000;'>E-mail e Confirmação de E-mail estão diferentes.</font>";
      }
      else
      {
        document.getElementById("span_msg").innerHTML = "";
      }
    }
    
    function BuscaCPF()
    {
      if (document.getElementById("cp_cpf").value != "") 
      {
        $.getJSON("cadastro_ajax.php", {param_funcao: "busca_cpf_col", param_cpf: document.getElementById("cp_cpf").value}, function(data){
          if (data[0] != 0)
          {
            document.getElementById("span_msg").innerHTML = "<font color='red'>CPF " + document.getElementById("cp_cpf").value + " já consta no cadastro.</font>";
          };
        });
      };
    }
    
    function BuscaEmail(vReferencia)
    {
      if (document.getElementById("cp_email").value != "") 
      {
        $.getJSON("cadastro_ajax.php", {param_funcao: "busca_email_col", param_email: document.getElementById("cp_email").value, param_referencia: vReferencia}, function(data){
          if (data[0] != 0)
          {
            document.getElementById("span_msg").innerHTML = "<font color='red'>E-mail " + document.getElementById("cp_email").value + " já consta no cadastro.</font>";
          };
        });
      };
    }
    
    function copia_nome()
    {
      if ($("#cp_nome_social").val() == "")
      {
        document.getElementById("cp_nome_social").value = $("#cp_nome_registro").val();
      }
    }
    
    function proximo_campo(vCampo)
    {
      if (vCampo == "cp_numero")
      {
        if ($("#cp_bairro").val() != "")
        {
          document.getElementById("cp_email").focus();
        }
      }
    }   
    </script>
    <style type="text/css">
	  @import "css.css";
    </style>
  </head>
  <body onLoad="Carrega_Formulario()">
    <div id="div_cabecalho"></div>
    <table width="100%" border="0" align="center" background="./img/fundo_principal.png">
      <tr>
        <td height="135px">
          <table width="1000px" border="0" align="center">
            <tr>
              <td class="titulo_azul_20" height="50px" colspan="2"><br><br>Cadastro de Vaga de Emprego<br><br></td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
    <center><br>
    <form id="FA" name="FA" method="post" action="cadastro_vaga_emprego.php">
      <table width="860px" border="0" cellspacing="2" cellpadding="2">
				<tr>
          <td class="fonte12_esq"><b>Empresa <span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="3"><input type="text" name="cp_empresa" id="cp_empresa" placeholder="Empresa que esta abrindo a vaga." value="<?php echo($param_empresa); ?>" size="95"></td>
        </tr>
				<tr>
          <td class="fonte12_esq"><b>Departamento <span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="3"><input type="text" name="cp_departamento" id="cp_departamento" placeholder="Departamento que vai executar as funções." value="<?php echo($param_departamento); ?>" size="95"></td>
        </tr>
				<tr>
          <td class="fonte12_esq"><b>Ocupação <span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="4">
            <select name='cp_ocupacao' id='cp_ocupacao'>
<?php 
     try 
     {
      $sql3 = "select cod_ocupacao, cod_ocupacao, concat(codigo,' - ',SUBSTR(ocupacao,1,75)) as codigo_ocupacao, ocupacao
                 from classificacao_ocupacao
                order by ocupacao";
      $stmt3= $pdo->prepare($sql3);
      $stmt3->execute();
    }
    catch(PDOException $e)
    {
      $e->getMessage();
      $vErroCodigo = $vErroCodigo ."Lista CBO. Erro: $e <br>";
      exit;
    };
    echo("<option value='0'></option>");
    while ($result3 = $stmt3->fetch(PDO::FETCH_ASSOC)) 
    {
      $vSelecionado = "";
      if ($result3["cod_ocupacao"] == $param_ocupacao) { $vSelecionado = "SELECTED"; };
      echo("<option value='". $result3["cod_ocupacao"] ."' ". $vSelecionado .">". $result3["codigo_ocupacao"] ."</option>");
    }
?>
              
            </select>
          </td>
        </tr>
				<tr>
          <td class="fonte12_esq" colspan="4">
            <b>Descritivo da Vaga <span style="color:red">*</span></b> (Digite uma breve descrição da vaga)<br>
            <textarea id="cp_descritivo_vaga" name="cp_descritivo_vaga" rows="10" cols="120"><?php echo($param_descritivo_vaga); ?></textarea>
          </td>
        </tr>
				<tr>
          <td class="fonte12_esq" colspan="4">
            <b>Conhecimentos Necessários <span style="color:red">*</span></b> (Digite quais os conhecimento o candidado deve ter.)<br>
            <textarea id="cp_conhecimento_necessario" name="cp_conhecimento_necessario" rows="10" cols="120"><?php echo($param_conhecimento_necessario); ?></textarea>
          </td>
        </tr>
				<tr>
          <td class="fonte12_esq"><b>Grau de Escolaridade Desejado <span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="4">
            <select name='cp_grau_escolar' id='cp_grau_escolar'>
<?php 
     try 
     {
      $sql3 = "select cod_grau_escolaridade, grau_escolaridade from grau_escolaridade order by cod_grau_escolaridade";
      $stmt3= $pdo->prepare($sql3);
      $stmt3->execute();
    }
    catch(PDOException $e)
    {
      $e->getMessage();
      $vErroCodigo = $vErroCodigo ."Busca tipo de telefone 01. Erro: $e <br>";
      exit;
    };
    while ($result3 = $stmt3->fetch(PDO::FETCH_ASSOC)) 
    {
      $vSelecionado = "";
      if ($result3["cod_grau_escolaridade"] == $param_grau_escolar) { $vSelecionado = "SELECTED"; };
      echo("<option value='". $result3["cod_grau_escolaridade"] ."' ". $vSelecionado .">". $result3["grau_escolaridade"] ."</option>");
    }
?>
              
            </select>
          </td>
        </tr>
				<tr>
          <td class="fonte12_esq"><b>Grau de Escolaridade Minímo<span style="color:red">*</span></b></td>
          <td class="fonte12_esq" colspan="4">
            <select name='cp_grau_escolar_minimo' id='cp_grau_escolar_minimo'>
              <option value=''></option>
<?php 
     try 
     {
      $sql3 = "select cod_grau_escolaridade, grau_escolaridade from grau_escolaridade order by cod_grau_escolaridade";
      $stmt3= $pdo->prepare($sql3);
      $stmt3->execute();
    }
    catch(PDOException $e)
    {
      $e->getMessage();
      $vErroCodigo = $vErroCodigo ."Busca tipo de telefone 01. Erro: $e <br>";
      exit;
    };
    while ($result3 = $stmt3->fetch(PDO::FETCH_ASSOC)) 
    {
      $vSelecionado = "";
      if ($result3["cod_grau_escolaridade"] == $param_grau_escolar_minimo) { $vSelecionado = "SELECTED"; };
      echo("<option value='". $result3["cod_grau_escolaridade"] ."' ". $vSelecionado .">". $result3["grau_escolaridade"] ."</option>");
    }
?>
              
            </select>
          </td>
        </tr>
				<tr>
          <td class="fonte12_esq" colspan="4">
            <b>Benefícios <span style="color:red">*</span></b> (Digite quais benefício tera na contratação)<br>
            <textarea id="cp_perfil" name="cp_beneficio" rows="10" cols="120"><?php echo($param_beneficio); ?></textarea>
          </td>
        </tr>
				<tr>
          <td class="fonte12_esq"><b>Salário <span style="color:red">*</span></b></td>
          <td class="fonte12_esq"><input type="text" name="cp_salario" id="cp_salario" placeholder="Salário Ofertado" value="<?php echo($param_salario); ?>" size="10"></td>
          
<?php if ($param_cod_vaga == "0") { ?>
          <td class="fonte12_esq" colspan="2"></td>
<?php } else { ?>
          <td class="fonte12_esq"><b>Situação <span style="color:red">*</span></b></td>
          <td class="fonte12_esq">
            <select name='cp_status' id='cp_status'>
              <option value='A' <?php echo($vStatusAberto); ?>>Aberta</option>
              <option value='F' <?php echo($vStatusFechado); ?>>Fechada</option>
            </select>
<?php } ?>
        </tr>
				<tr>
          <td class="fonte14" colspan="4"><span id="span_msg"><?php echo($vCamposObrigatorios); ?></span></td>
        </tr>
				<tr>
          <td class="fonte14" colspan="4">
<?php if ($param_cod_vaga == "0") { ?>
            <input type="submit" class="button_padrao" name="bt_gravar" value="&nbsp;&nbsp;Gravar&nbsp;&nbsp;">
<?php } else { ?>
            <input type="submit" class="button_padrao" name="bt_alterar" value="&nbsp;&nbsp;Alterar&nbsp;&nbsp;">
<?php } ?>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="submit" class="button_padrao" name="bt_voltar" value="&nbsp;&nbsp;Voltar&nbsp;&nbsp;">
          </td>
        </tr>
      </table>
      <input type="hidden" id="param_cod_vaga" name="param_cod_vaga" value="<?PHP echo($param_cod_vaga); ?>">
    </form>
    <?php echo($vErroCodigo); ?>
  </body>
</html>