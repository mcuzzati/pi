<?PHP
  session_destroy();
  echo("<script language='Javascript'>window.location = 'index.php'</script>");
?>
