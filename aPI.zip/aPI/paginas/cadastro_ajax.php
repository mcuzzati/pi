<?PHP	 
	require_once("seg_conexao.php");
  require_once("funcoes.php");
		   
	if ($_REQUEST["param_funcao"] == "busca_cep") 
  {
    try 
    {
      $pdo = connect();
      $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch(PDOException $e) {
      $e->getMessage();
      echo "<span class='fonte_doze_negrito_erro'>[ Erro $e ]</span>";
      exit;
    };

		try 
    {
      $vRetorno = array();
			$sql = "select uf,
                     localidade,
                     bairro,
                     concat(tipo, ' ', logradouro) as logradouro,
                     complemento
                from adm_cep_publico.ger_cep_geral 
               where cep = trim(replace(replace(:CEP,'.',''),'-',''))";
      $parametros_sql = array(":CEP"=>$_REQUEST["param_cep"]);
			$stmt= $pdo->prepare($sql);
			$stmt->execute($parametros_sql);
			$result = $stmt->fetch(PDO::FETCH_ASSOC);
      if (!empty($result['uf']))
      {
        $vRetorno[0] = $result['uf'];
        $vRetorno[1] = $result['localidade'];
        $vRetorno[2] = $result['bairro'];
        $vRetorno[3] = $result['logradouro'];
        $vRetorno[4] = $result['complemento'];
      } 
      else
      {
        $vRetorno[0] = "";
        $vRetorno[1] = "";
        $vRetorno[2] = "";
        $vRetorno[3] = "";
        $vRetorno[4] = "";
      }
			echo(json_encode($vRetorno));
		} catch(PDOException $e) {
			$e->getMessage();
			echo(json_encode(array("Erro $e")));
		};
    
    $pdo = null;
	};
  
	if ($_REQUEST["param_funcao"] == "busca_cpf" or $_REQUEST["param_funcao"] == "busca_cpf_col") 
  {
    if ($_REQUEST["param_funcao"] == "busca_cpf") 
    {
      $vTipoCadastro = "CN";
    }
    else
    {
      $vTipoCadastro = "CL";
    }
    
    try 
    {
      $pdo = connect();
      $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch(PDOException $e) {
      $e->getMessage();
      echo "<span class='fonte_doze_negrito_erro'>[ Erro $e ]</span>";
      exit;
    };

		try 
    {
      $vRetorno = array();
			$sql = "select count(1) as qtde
                from pessoa p
                      inner join usuario u on (u.cod_pessoa = p.cod_pessoa)
               where u.tipo_usuario = :TIPO_USUARIO
                 and p.cpf = :CPF";
      $parametros_sql = array(":TIPO_USUARIO"=>$vTipoCadastro, ":CPF"=>so_numero($_REQUEST["param_cpf"]));
			$stmt= $pdo->prepare($sql);
			$stmt->execute($parametros_sql);
			$result = $stmt->fetch(PDO::FETCH_ASSOC);
      
      $vRetorno[0] = $result['qtde'];
      $vRetorno[1] = "";
      
			echo(json_encode($vRetorno));
		} catch(PDOException $e) {
			$e->getMessage();
			echo(json_encode(array("Erro $e")));
		};
    
    $pdo = null;
	};
  
	if ($_REQUEST["param_funcao"] == "busca_email" or $_REQUEST["param_funcao"] == "busca_email_col") 
  {
    if ($_REQUEST["param_funcao"] == "busca_email") 
    {
      $vTipoCadastro = "CN";
    }
    else
    {
      $vTipoCadastro = "CL";
    }
    
    if (!empty($_REQUEST["param_referencia"])) { $varCodigoPessoa = $_REQUEST["param_referencia"]; } else { $varCodigoPessoa = 0; };
    
    try 
    {
      $pdo = connect();
      $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch(PDOException $e) {
      $e->getMessage();
      echo "<span class='fonte_doze_negrito_erro'>[ Erro $e ]</span>";
      exit;
    };

		try 
    {
      $vRetorno = array();
			$sql = "select count(1) as qtde
                from pessoa p
                      inner join usuario u on (u.cod_pessoa = p.cod_pessoa)
               where p.cod_pessoa <> :COD_PESSOA
                 and u.tipo_usuario = :TIPO_USUARIO
                 and p.email = :EMAIL";
      $parametros_sql = array(":COD_PESSOA"=>$varCodigoPessoa, ":TIPO_USUARIO"=>$vTipoCadastro, ":EMAIL"=>trim($_REQUEST["param_email"]));
			$stmt= $pdo->prepare($sql);
			$stmt->execute($parametros_sql);
			$result = $stmt->fetch(PDO::FETCH_ASSOC);
      
      $vRetorno[0] = $result['qtde'];
      $vRetorno[1] = "";
      
			echo(json_encode($vRetorno));
		} catch(PDOException $e) {
			$e->getMessage();
			echo(json_encode(array("Erro $e")));
		};
    
    $pdo = null;
	};
?>