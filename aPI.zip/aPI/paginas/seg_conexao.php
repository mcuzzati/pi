<?PHP
	function connect()
	{
		$hostname = "sql313.infinityfree.com";
    //$porta = "3308";
		$username = "if0_36325418"; 
		$password = "q5XpZXssllKwSN";
		$dbname = "if0_36325418_bd_projeto_integrado"; 
		try {
			$vConexao = new PDO("mysql:host=".$hostname.";port=".$porta.";dbname=".$dbname, $username, $password, array(PDO::MYSQL_ATTR_INIT_COMMAND =>  "SET NAMES utf8mb4"));
    } catch(PDOException $e) {
      $e->getMessage();
			$vConexao = null;
			echo("Erro ao conectar! Solicite suporte.");
      exit;
    };
		return $vConexao;
	};
?>